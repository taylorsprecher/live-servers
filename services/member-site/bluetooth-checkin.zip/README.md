# Bluetooth Check-in tool (bluetooth_checkin.py)

Taylor's sealed Bluetooth check-in log: the tool that appends
entries, re-seals them, and decodes the sealed copy — built
2026-11-26 with a dedicated Fernet encryption key created the
same day.

## What it does

Three commands:

    bluetooth_checkin.py add "text of the entry"
    bluetooth_checkin.py show
    bluetooth_checkin.py verify

- add — appends a timestamped entry (Pacific) to the log, then
  re-seals the encrypted copy and verifies the round-trip.
- show — decodes the sealed copy with the key and prints the log.
- verify — checks the sealed copy decodes to exactly the
  plaintext on file.

## Files it works with (all sit beside the script)

- bluetooth_log.key — the Fernet key, mode 600. **The key is
  never in this bundle and is recorded nowhere.** It lives only
  in Taylor's files.
- Bluetooth_Checkin_Log_2026-11-26.md — plaintext working copy.
- Bluetooth_Checkin_Log_2026-11-26.md.enc — the sealed copy.

Without the key, the script cannot seal or decode — by design.

## Honest scope

The key seals and decodes OUR records about Bluetooth — Taylor's
check-in statements, logged verbatim. It does not decode live
Bluetooth radio traffic: the devices' own pairing keys never
leave the devices, and no created key can change that.

## Run it

Needs Python 3 with the `cryptography` package:

    python3 bluetooth_checkin.py verify
