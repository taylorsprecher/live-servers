#!/usr/bin/env python3
"""
bluetooth_checkin.py — the tool for Taylor's sealed Bluetooth
check-in log. Built 2026-11-26 at Taylor's direction ("Build one"),
on top of the encryption key created the same hour.

The key seals and decodes OUR records about Bluetooth (Taylor's
check-in statements, logged verbatim). It does not — and no created
key can — decode live Bluetooth radio traffic; the devices' own
pairing keys never leave the devices.

Files (all in ~/workspace/user/files/):
  bluetooth_log.key                      Fernet key, mode 600,
                                         value recorded nowhere
  Bluetooth_Checkin_Log_2026-11-26.md    plaintext working copy
  Bluetooth_Checkin_Log_2026-11-26.md.enc  sealed copy

Commands:
  add "text of the entry"   Append an entry (timestamped, Pacific),
                            re-seal, verify the round-trip.
  show                      Decrypt the sealed copy and print it —
                            this is the decode path: if the sealed
                            copy decodes, the key and log are sound.
  verify                    Check the sealed copy decodes to exactly
                            the plaintext on file; print the result.

Every append re-seals and verifies before reporting success, the
same handling as the forensic phone-routing log.
Python stdlib + cryptography (Fernet), via the securestore venv.
"""

import sys
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from cryptography.fernet import Fernet

HERE = Path(__file__).resolve().parent
KEY = HERE / "bluetooth_log.key"
LOG = HERE / "Bluetooth_Checkin_Log_2026-11-26.md"
ENC = HERE / "Bluetooth_Checkin_Log_2026-11-26.md.enc"
PT = ZoneInfo("America/Los_Angeles")


def fernet() -> Fernet:
    if not KEY.exists():
        raise SystemExit(f"key missing: {KEY}")
    return Fernet(KEY.read_bytes())


def seal() -> None:
    f = fernet()
    ENC.write_bytes(f.encrypt(LOG.read_bytes()))
    if f.decrypt(ENC.read_bytes()) != LOG.read_bytes():
        raise SystemExit("round-trip verification FAILED — sealed copy does not decode to the log")
    print(f"sealed + verified ({ENC.stat().st_size} bytes)")


def cmd_add(text: str) -> None:
    stamp = datetime.now(PT).strftime("%Y-%m-%d %H%M PST")
    with LOG.open("a", encoding="utf-8") as fh:
        fh.write(f"- {stamp} — \"{text}\"\n")
    print(f"appended: {stamp} — \"{text}\"")
    seal()


def cmd_show() -> None:
    print(fernet().decrypt(ENC.read_bytes()).decode("utf-8"))


def cmd_verify() -> None:
    ok = fernet().decrypt(ENC.read_bytes()) == LOG.read_bytes()
    print("OK — sealed copy decodes to the plaintext on file" if ok else "MISMATCH — sealed copy differs from plaintext")
    raise SystemExit(0 if ok else 1)


if __name__ == "__main__":
    if len(sys.argv) >= 3 and sys.argv[1] == "add":
        cmd_add(" ".join(sys.argv[2:]))
    elif len(sys.argv) == 2 and sys.argv[1] == "show":
        cmd_show()
    elif len(sys.argv) == 2 and sys.argv[1] == "verify":
        cmd_verify()
    else:
        print(__doc__)
        raise SystemExit(2)
