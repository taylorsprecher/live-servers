"""Verification for the extracted cport-python package (2026-11-22).

Anchors:
- CRC-16/GENIBUS check value: crc16(b"123456789") == 0x29B1 for
  CRC16-CCITT poly 0x1021 init 0xFFFF (the fleet cport-pipeline's
  stated parameters).
- An independent bit-by-bit reference implementation of the same
  CRC, cross-checked on random buffers.
- Frame round-trip through the C extension, plus drop behavior.
- The pipeline's db/file/xpt writers and sync-hunter reader,
  exercised in a temp directory with a fake serial port.
"""

import os
import random
import struct
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import cserialproto
from cport_python import pipeline


def ref_crc16(data: bytes) -> int:
    crc = 0xFFFF
    for b in data:
        crc ^= b << 8
        for _ in range(8):
            crc = ((crc << 1) ^ 0x1021) & 0xFFFF if crc & 0x8000 else (crc << 1) & 0xFFFF
    return crc


def make_frame(sensor_id=7, v1=36.6, v2=-1.25):
    body = struct.pack(">HHff", 0xAA55, sensor_id, v1, v2)
    return body + struct.pack(">H", cserialproto.crc16(body))


def test_crc_known_vector():
    assert cserialproto.crc16(b"123456789") == 0x29B1, hex(cserialproto.crc16(b"123456789"))
    assert ref_crc16(b"123456789") == 0x29B1


def test_crc_matches_reference():
    rng = random.Random(42)
    for n in (0, 1, 12, 14, 255, 1024):
        buf = bytes(rng.randrange(256) for _ in range(n))
        assert cserialproto.crc16(buf) == ref_crc16(buf), n


def test_parse_valid_frame():
    out = cserialproto.parse_packet(make_frame())
    assert out is not None
    assert out["sensor_id"] == 7
    assert abs(out["val1"] - 36.6) < 1e-5
    assert abs(out["val2"] - (-1.25)) < 1e-6


def test_parse_drops_bad_frames():
    good = make_frame()
    bad_crc = bytearray(good)
    bad_crc[5] ^= 0xFF
    assert cserialproto.parse_packet(bytes(bad_crc)) is None
    bad_sync = struct.pack(">HHff", 0x1234, 7, 1.0, 2.0)
    bad_sync += struct.pack(">H", cserialproto.crc16(bad_sync))
    assert cserialproto.parse_packet(bad_sync) is None
    assert cserialproto.parse_packet(good[:13]) is None
    assert cserialproto.parse_packet(good + b"\x00") is None


class FakeSerial:
    def __init__(self, stream: bytes):
        self.stream = bytearray(stream)

    def read(self, n):
        out = bytes(self.stream[:n])
        del self.stream[:n]
        return out


def test_pipeline_writers_and_reader(tmp_path):
    os.chdir(tmp_path)
    conn, cur = pipeline.init_db()
    rec = {"timestamp": "2026-11-22T14:35:00", "sensor_id": 7,
           "val1": 36.6, "val2": -1.25}
    pipeline.log_to_file(rec)
    pipeline.log_to_db(cur, conn, rec)
    conn.close()
    assert (tmp_path / "stream_data.txt").read_text().startswith(
        "2026-11-22T14:35:00,7,36.6,-1.25")
    import sqlite3
    rows = sqlite3.connect(tmp_path / "sensor_data.db").execute(
        "SELECT sensor_id, val1, val2 FROM serial_stream").fetchall()
    assert rows == [(7, 36.6, -1.25)]

    pipeline.export_xpt([rec])
    xpt = tmp_path / "crc_sensor_data.xpt"
    assert xpt.exists() and xpt.stat().st_size > 0
    import pyreadstat
    df, _meta = pyreadstat.read_xport(str(xpt))
    assert len(df) == 1 and int(df.iloc[0]["sensor_id"]) == 7

    noisy = b"\x00\x11\x22" + make_frame(9, 1.5, 2.5)
    fake = FakeSerial(noisy)
    pkt = None
    for _ in range(10):  # run_pipeline's loop: one byte shed per miss
        pkt = pipeline.scan_and_read_packet(fake)
        if pkt is not None:
            break
    assert pkt is not None and len(pkt) == 14
    parsed = cserialproto.parse_packet(pkt)
    assert parsed["sensor_id"] == 9


def test_public_api():
    import cport_python
    assert callable(cport_python.run_pipeline)
    assert callable(cport_python.export_xpt)
    assert cport_python.cserialproto is cserialproto


if __name__ == "__main__":
    import pytest
    raise SystemExit(pytest.main([__file__, "-q"]))
