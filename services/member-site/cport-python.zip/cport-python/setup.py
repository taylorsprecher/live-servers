from setuptools import setup, Extension, find_packages

cserialproto = Extension(
    "cserialproto",
    sources=["cserialproto.c"]
)

setup(
    name="cport-python",
    version="1.0.0",
    packages=find_packages(),
    ext_modules=[cserialproto]
)
