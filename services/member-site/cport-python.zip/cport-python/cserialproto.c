#define PY_SSIZE_T_CLEAN
#include <Python.h>
#include <stdint.h>

#define PACKET_SIZE 14
#define SYNC_MARKER 0xAA55

static uint16_t crc16_ccitt(const uint8_t *data, Py_ssize_t len) {
    uint16_t crc = 0xFFFF;
    for (Py_ssize_t i = 0; i < len; i++) {
        crc ^= (uint16_t)data[i] << 8;
        for (int j = 0; j < 8; j++) {
            if (crc & 0x8000)
                crc = (crc << 1) ^ 0x1021;
            else
                crc <<= 1;
            crc &= 0xFFFF;
        }
    }
    return crc;
}

static PyObject *csp_crc16(PyObject *self, PyObject *args) {
    const uint8_t *buf;
    Py_ssize_t len;
    if (!PyArg_ParseTuple(args, "y#", &buf, &len))
        return NULL;
    uint16_t crc = crc16_ccitt(buf, len);
    return PyLong_FromUnsignedLong(crc);
}

static PyObject *csp_parse_packet(PyObject *self, PyObject *args) {
    const uint8_t *buf;
    Py_ssize_t len;
    if (!PyArg_ParseTuple(args, "y#", &buf, &len))
        return NULL;

    if (len != PACKET_SIZE)
        Py_RETURN_NONE;

    uint16_t sync = (buf[0] << 8) | buf[1];
    if (sync != SYNC_MARKER)
        Py_RETURN_NONE;

    uint16_t sensor_id = (buf[2] << 8) | buf[3];

    union { uint32_t u; float f; } v1, v2;
    v1.u = ((uint32_t)buf[4] << 24) |
           ((uint32_t)buf[5] << 16) |
           ((uint32_t)buf[6] << 8)  |
           ((uint32_t)buf[7]);

    v2.u = ((uint32_t)buf[8] << 24) |
           ((uint32_t)buf[9] << 16) |
           ((uint32_t)buf[10] << 8) |
           ((uint32_t)buf[11]);

    uint16_t received_crc = (buf[12] << 8) | buf[13];
    uint16_t calc_crc = crc16_ccitt(buf, PACKET_SIZE - 2);

    if (calc_crc != received_crc)
        Py_RETURN_NONE;

    PyObject *result = PyDict_New();
    PyDict_SetItemString(result, "sensor_id", PyLong_FromUnsignedLong(sensor_id));
    PyDict_SetItemString(result, "val1", PyFloat_FromDouble(v1.f));
    PyDict_SetItemString(result, "val2", PyFloat_FromDouble(v2.f));
    return result;
}

static PyMethodDef CSerialProtoMethods[] = {
    {"crc16", csp_crc16, METH_VARARGS, "Compute CRC16-CCITT over a byte buffer."},
    {"parse_packet", csp_parse_packet, METH_VARARGS, "Parse and validate a 14-byte framed packet (>HHffH)."},
    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef cserialproto_module = {
    PyModuleDef_HEAD_INIT,
    "cserialproto",
    "CPython extension for framed CRC16 serial packet verification.",
    -1,
    CSerialProtoMethods
};

PyMODINIT_FUNC PyInit_cserialproto(void) {
    return PyModule_Create(&cserialproto_module);
}
