# C-Port Python (cport-python)

CPython extension for framed CRC16 serial packet ingestion and SAS
XPORT pipeline generation — the "C-Port to Lightning Python" build:
the USB-C to Lightning power/protocol material and the C-Port Python
package from Taylor's C-Port_Python.docx (filed 2026-11-03),
extracted and built 2026-11-22 at Taylor's direction.

## What it is

- `cserialproto.c` — a CPython C extension that validates the
  14-byte frame (sync 0xAA55, big-endian `>HHffH`), verifies the
  CRC16-CCITT checksum (poly 0x1021, init 0xFFFF, over the first
  12 bytes), and returns the parsed reading as a dict.
- `cport_python/pipeline.py` — the ingestion pipeline: sync-hunter
  serial reader, dual-write logging (append-only text stream +
  SQLite `sensor_data.db`), and SAS XPORT (.xpt) export via
  pyreadstat on shutdown.
- `cport_python/__init__.py` — public API: `run_pipeline`,
  `export_xpt`, `cserialproto`.

## Build and install

```
python setup.py build_ext --inplace
pip install .
```

## Run

```
from cport_python import run_pipeline
run_pipeline(port="COM3", baud=9600)
```

Verified 2026-11-22: the C extension's CRC16 matches the fleet
cport-pipeline's pure-Python CRC16-CCITT on every test buffer, valid
frames parse to the packed values, and corrupt-CRC / wrong-sync /
wrong-length frames are dropped.
