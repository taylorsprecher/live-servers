import datetime
import sqlite3
import serial
import pandas as pd
import pyreadstat
import cserialproto

SERIAL_PORT = "COM3"
BAUD_RATE = 9600
DB_FILE = "sensor_data.db"
OUTPUT_FILE = "stream_data.txt"
XPT_FILE = "crc_sensor_data.xpt"
PACKET_SIZE = 14
SYNC_MARKER = b"\xAA\x55"

def init_db():
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS serial_stream (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT,
            sensor_id INTEGER,
            val1 REAL,
            val2 REAL,
            raw_data TEXT
        )
    """)
    conn.commit()
    return conn, cur

def scan_and_read_packet(ser: serial.Serial) -> bytes | None:
    b1 = ser.read(1)
    if not b1 or b1 != SYNC_MARKER[0:1]:
        return None
    b2 = ser.read(1)
    if b2 != SYNC_MARKER[1:2]:
        return None
    
    payload = ser.read(PACKET_SIZE - 2)
    if len(payload) != PACKET_SIZE - 2:
        return None
    return SYNC_MARKER + payload

def log_to_file(record: dict):
    with open(OUTPUT_FILE, "a") as f:
        f.write(f"{record['timestamp']},{record['sensor_id']},{record['val1']},{record['val2']}\n")
        f.flush()

def log_to_db(cur: sqlite3.Cursor, conn: sqlite3.Connection, record: dict):
    cur.execute(
        "INSERT INTO serial_stream (timestamp, sensor_id, val1, val2, raw_data) VALUES (?, ?, ?, ?, ?)",
        (record['timestamp'], record['sensor_id'], record['val1'], record['val2'], str(record))
    )
    conn.commit()

def export_xpt(records: list):
    if not records:
        print("No valid records to export.")
        return
    df = pd.DataFrame(records)
    pyreadstat.write_xport(df, XPT_FILE, table_name="SENSORS", file_label="CRC Validated Stream")
    print(f"Successfully exported {len(df)} records to SAS Transport file: {XPT_FILE}")

def run_pipeline(port: str = SERIAL_PORT, baud: int = BAUD_RATE):
    conn, cur = init_db()
    ser = serial.Serial(port, baud, timeout=1)
    print(f"CPython Protocol Engine online. Listening on {port} at {baud} baud...")
    
    buffer = []
    try:
        while True:
            raw_packet = scan_and_read_packet(ser)
            if not raw_packet:
                continue
                
            parsed = cserialproto.parse_packet(raw_packet)
            if parsed is None:
                print("CRC16 or framing validation failed — Packet dropped.")
                continue
                
            parsed["timestamp"] = datetime.datetime.now().isoformat()
            buffer.append(parsed)
            
            log_to_file(parsed)
            log_to_db(cur, conn, parsed)
            
            print(f"Valid Frame -> ID={parsed['sensor_id']} V1={parsed['val1']:.4f} V2={parsed['val2']:.4f}")
    except KeyboardInterrupt:
        print("\nShutdown signal received. Flushing buffers and tearing down pipeline...")
    finally:
        ser.close()
        conn.close()
        export_xpt(buffer)

if __name__ == "__main__":
    run_pipeline()
