"""Uploader tests — the server contract is the source of truth:
session ids match ^[a-z0-9][a-z0-9-]{2,39}$, uploads POST raw bytes
to /members/stream/upload?session&seq&ext, 200 + "ok ..." wins."""

import re

from streammic import uploader

SESSION_RE = re.compile(r"^[a-z0-9][a-z0-9-]{2,39}$")


class FakeResponse:
    status = 200

    def __init__(self, body=b"ok chunk-0001.m4a"):
        self._body = body

    def read(self):
        return self._body

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


def test_session_id_shape():
    for _ in range(50):
        sid = uploader.new_session_id()
        assert SESSION_RE.match(sid), sid


def test_upload_url():
    url = uploader.upload_url("https://example.net/", "app-abc123", 7, "m4a")
    assert url == (
        "https://example.net/members/stream/upload"
        "?session=app-abc123&seq=7&ext=m4a"
    )


def test_upload_chunk_ok():
    seen = {}

    def opener(req, timeout=None):
        seen["url"] = req.full_url
        seen["data"] = req.data
        return FakeResponse()

    ok, msg = uploader.upload_chunk(
        b"\x00\x01\x02", "app-abc123", 1, "m4a",
        base="https://example.net", opener=opener,
    )
    assert ok and msg.startswith("ok")
    assert seen["data"] == b"\x00\x01\x02"
    assert "seq=1" in seen["url"]


def test_upload_chunk_server_error():
    def opener(req, timeout=None):
        return FakeResponse(b"error bad session")

    ok, msg = uploader.upload_chunk(
        b"x", "app-abc123", 1, "m4a", base="https://example.net", opener=opener
    )
    assert not ok and "bad session" in msg


def test_upload_chunk_empty_and_huge():
    ok, _ = uploader.upload_chunk(b"", "app-abc123", 1, "m4a")
    assert not ok
    ok, _ = uploader.upload_chunk(
        b"x" * (uploader.MAX_CHUNK_BYTES + 1), "app-abc123", 1, "m4a"
    )
    assert not ok
