"""StreamCore tests — a fake recorder and a fake uploader prove the
loop: chunks are numbered from 1, uploaded with the session id, and
counted; Stop ends the loop."""

import time

from streammic.streamcore import StreamCore


class FakeRecorder:
    def __init__(self):
        self.cancelled = False

    def prepare(self):
        return True, "ready"

    def record_chunk(self, seconds):
        time.sleep(0.02)
        if self.cancelled:
            return False, "cancelled"
        return True, b"chunk-bytes"

    def cancel(self):
        self.cancelled = True


def test_loop_uploads_numbered_chunks():
    uploads = []

    def fake_upload(data, session, seq, ext, base=None):
        uploads.append((session, seq, ext, data))
        return True, "ok chunk-%04d.%s" % (seq, ext)

    core = StreamCore(recorder=FakeRecorder(), upload_fn=fake_upload)
    ok, msg = core.start()
    assert ok and core.session in msg
    time.sleep(0.25)
    core.stop()
    assert core.sent >= 2
    assert core.failed == 0
    seqs = [u[1] for u in uploads]
    assert seqs == list(range(1, len(seqs) + 1))
    assert all(u[0] == core.session and u[2] == "m4a" for u in uploads)


def test_start_refused_when_recorder_cannot_prepare():
    class DeafRecorder(FakeRecorder):
        def prepare(self):
            return False, "microphone permission was not granted"

    core = StreamCore(recorder=DeafRecorder(), upload_fn=lambda *a, **k: (True, "ok"))
    ok, msg = core.start()
    assert not ok and "permission" in msg
    assert not core.running
