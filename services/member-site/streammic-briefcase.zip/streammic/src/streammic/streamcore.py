"""Stream Mic — the streaming loop.

Pure control logic: while enabled, record one chunk, upload it,
count it, repeat. The recorder and the uploader are injected, so
the loop is unit-testable off-device; on the phone the recorder is
the AVAudioRecorder bridge in recorder.py and the uploader is
uploader.upload_chunk.

One Enable press runs the loop until Stop: no browser, no pop-out.
The only prompt in the flow is iOS's own microphone permission,
which the recorder requests once when capture first starts.
"""

import threading
import time

from . import uploader as uploader_mod

CHUNK_SECONDS = 10
CHUNK_EXT = "m4a"


class StreamCore:
    """Start/stop chunk streaming on a background thread."""

    def __init__(self, recorder, upload_fn=None, base=uploader_mod.DEFAULT_BASE,
                 on_status=None):
        self.recorder = recorder
        self.upload_fn = upload_fn or uploader_mod.upload_chunk
        self.base = base
        self.on_status = on_status or (lambda text: None)
        self.session = None
        self.sent = 0
        self.failed = 0
        self._stop = threading.Event()
        self._thread = None

    @property
    def running(self):
        return self._thread is not None and self._thread.is_alive()

    def start(self):
        """Begin streaming; return (ok, message)."""
        if self.running:
            return False, "already streaming"
        ok, msg = self.recorder.prepare()
        if not ok:
            return False, msg
        self.session = uploader_mod.new_session_id()
        self.sent = 0
        self.failed = 0
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        return True, "streaming (session %s)" % self.session

    def stop(self):
        """Stop after the current chunk; safe to call when idle."""
        self._stop.set()
        self.recorder.cancel()
        if self._thread is not None:
            self._thread.join(timeout=CHUNK_SECONDS + 15)
        self._thread = None

    def _loop(self):
        seq = 0
        while not self._stop.is_set():
            seq += 1
            ok, payload = self.recorder.record_chunk(CHUNK_SECONDS)
            if self._stop.is_set():
                break
            if not ok:
                self.failed += 1
                self.on_status("record failed: %s" % payload)
                time.sleep(1)
                continue
            ok, msg = self.upload_fn(
                payload, self.session, seq, CHUNK_EXT, base=self.base
            )
            if ok:
                self.sent += 1
            else:
                self.failed += 1
            self.on_status(
                "sent %d chunk(s), %d failed — %s"
                % (self.sent, self.failed, msg)
            )
