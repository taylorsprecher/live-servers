"""Stream Mic — iOS microphone bridge (AVFoundation via rubicon).

Records the microphone with AVAudioRecorder into temporary .m4a
files, one file per chunk. This is the only module that touches
iOS frameworks; it imports rubicon lazily so the package compiles
and its other modules test cleanly off-device. Off iOS, prepare()
reports plainly that capture is unavailable here.

Permission: AVAudioSession.requestRecordPermission is iOS's own
microphone prompt — asked once, inside the app. There is no
browser and no Safari pop-out anywhere in this flow.
"""

import os
import tempfile
import threading


class IOSRecorder:
    """AVAudioRecorder-backed chunk recorder (iOS only)."""

    def __init__(self):
        self._objc = None  # (AVAudioSession, AVAudioRecorder classes, NSURL)
        self._recorder = None
        self._path = None
        self._done = threading.Event()
        self._granted = None

    # -- platform -------------------------------------------------
    def _load(self):
        if self._objc is not None:
            return True
        try:
            from rubicon.objc import ObjCClass, objc_method  # noqa: F401
            from rubicon.objc.runtime import load_library
            load_library("AVFoundation")
            self._objc = (
                ObjCClass("AVAudioSession"),
                ObjCClass("AVAudioRecorder"),
                ObjCClass("NSURL"),
            )
            return True
        except Exception:
            return False

    # -- recorder contract ----------------------------------------
    def prepare(self):
        """Ask for microphone permission; return (ok, message)."""
        if not self._load():
            return False, "microphone capture needs the iOS app (AVFoundation)"
        AVAudioSession, _, _ = self._objc
        session = AVAudioSession.sharedInstance()
        session.setCategory_error_("AVAudioSessionCategoryPlayAndRecord", None)
        session.setActive_error_(True, None)
        self._done.clear()
        self._granted = None

        def _answer(granted):
            self._granted = bool(granted)
            self._done.set()

        session.requestRecordPermission_(_answer)
        if not self._done.wait(timeout=60):
            return False, "microphone permission was not answered"
        if not self._granted:
            return False, "microphone permission was not granted"
        return True, "microphone ready"

    def record_chunk(self, seconds):
        """Record one chunk; return (ok, bytes-or-message)."""
        if not self._load():
            return False, "microphone capture needs the iOS app (AVFoundation)"
        _, AVAudioRecorder, NSURL = self._objc
        fd, path = tempfile.mkstemp(suffix=".m4a")
        os.close(fd)
        self._path = path
        url = NSURL.fileURLWithPath_(path)
        # AAC in an MPEG-4 container: AVFormatIDKey kAudioFormatMPEG4AAC
        settings = {
            "AVFormatIDKey": 1633772320,
            "AVSampleRateKey": 44100.0,
            "AVNumberOfChannelsKey": 1,
            "AVEncoderAudioQualityKey": 96,  # AVAudioQualityHigh
        }
        recorder = AVAudioRecorder.alloc().initWithURL_settings_error_(
            url, settings, None
        )
        if recorder is None:
            return False, "could not create the recorder"
        self._recorder = recorder
        recorder.record()
        # Sleep in short steps so cancel() can cut the chunk short.
        waited = 0.0
        while waited < seconds and self._recorder is not None:
            threading.Event().wait(0.25)
            waited += 0.25
        return self._finish()

    def cancel(self):
        """Cut the current chunk short (used by Stop)."""
        self._recorder = None

    def _finish(self):
        recorder, self._recorder = self._recorder, None
        if recorder is not None:
            recorder.stop()
        path, self._path = self._path, None
        if not path or not os.path.exists(path):
            return False, "no recording was made"
        try:
            with open(path, "rb") as fh:
                data = fh.read()
        finally:
            try:
                os.unlink(path)
            except OSError:
                pass
        if not data:
            return False, "the recording was empty"
        return True, data
