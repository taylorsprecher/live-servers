"""Stream Mic — phone-side streaming to the member-server receiver.

Pure upload half of the app: builds the receiver URL, generates
session ids the server accepts, and posts one recorded chunk per
call. Kept free of any iOS or UI imports so it can be unit-tested
anywhere.

Server contract (the original /members/stream/upload protocol,
open access): POST the raw chunk bytes to
    {base}/members/stream/upload?session=<id>&seq=<n>&ext=<ext>
Session ids match ^[a-z0-9][a-z0-9-]{2,39}$; ext is one of
mp4/webm/ogg/wav/m4a/bin; a chunk is at most 5 MB. The server
answers 200 with a body starting "ok " on success.
"""

import secrets
import string
import urllib.request

DEFAULT_BASE = "https://members.911transedu.net"
UPLOAD_PATH = "/members/stream/upload"
MAX_CHUNK_BYTES = 5 * 1024 * 1024

_ALPHABET = string.ascii_lowercase + string.digits


def new_session_id(prefix="app"):
    """A fresh session id the server's token rule accepts."""
    token = "".join(secrets.choice(_ALPHABET) for _ in range(10))
    return "%s-%s" % (prefix, token)


def upload_url(base, session, seq, ext):
    return "%s%s?session=%s&seq=%d&ext=%s" % (
        base.rstrip("/"),
        UPLOAD_PATH,
        session,
        int(seq),
        ext,
    )


def upload_chunk(data, session, seq, ext, base=DEFAULT_BASE, opener=None):
    """POST one chunk; return (ok, message). Never raises."""
    if not data:
        return False, "empty chunk"
    if len(data) > MAX_CHUNK_BYTES:
        return False, "chunk too large"
    url = upload_url(base, session, seq, ext)
    req = urllib.request.Request(
        url,
        data=bytes(data),
        method="POST",
        headers={"Content-Type": "application/octet-stream"},
    )
    open_fn = opener or urllib.request.urlopen
    try:
        with open_fn(req, timeout=30) as resp:
            body = resp.read().decode("utf-8", "replace")
            status = getattr(resp, "status", 200)
    except Exception as exc:  # network down, server error, timeout
        return False, "upload failed: %s" % exc
    if status == 200 and body.startswith("ok"):
        return True, body.strip()
    return False, "server said: %s" % body.strip()
