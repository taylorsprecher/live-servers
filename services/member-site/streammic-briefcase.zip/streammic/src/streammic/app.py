"""Stream Mic — stream this phone's microphone to the member server.

A Toga front-end over streamcore: one Enable button starts the
chunks flowing to the receiver on Taylor's member server; Stop
ends the session. Built 2026-11-25 at Taylor's direction ("Create
python" — a Python app for the phone, like SSK Python), so pushing
Enable creates the stream with no Safari step in between. The
receiver stays on the server, exactly as it is.
"""

import toga
from toga.style.pack import COLUMN, PACK

from .recorder import IOSRecorder
from .streamcore import StreamCore


class StreamMic(toga.App):
    def startup(self):
        self.core = StreamCore(
            recorder=IOSRecorder(),
            on_status=self._show_status,
        )
        self.status = toga.Label(
            "Stopped. Tap Enable to start streaming this phone's "
            "microphone to your member server in 10-second chunks. "
            "The first start asks iOS for microphone permission — "
            "that prompt is the only one; there is no browser step.",
            style=PACK(padding=12),
        )
        self.toggle = toga.Button(
            "Enable",
            on_press=self._toggle,
            style=PACK(padding=12),
        )
        box = toga.Box(
            children=[self.toggle, self.status],
            style=PACK(direction=COLUMN, padding=10),
        )
        self.main_window = toga.MainWindow(title=self.formal_name)
        self.main_window.content = box
        self.main_window.show()

    def _show_status(self, text):
        self.status.text = text

    def _toggle(self, _widget):
        if self.core.running:
            self.core.stop()
            self.toggle.text = "Enable"
            self._show_status(
                "Stopped. Sent %d chunk(s), %d failed."
                % (self.core.sent, self.core.failed)
            )
            return
        ok, msg = self.core.start()
        if ok:
            self.toggle.text = "Stop"
        self._show_status(msg)


def main():
    return StreamMic()
