# Stream Mic

A Python app for the phone (BeeWare Briefcase / Toga), built
2026-11-25 at Taylor's direction: "Create python" — a Python app
for the phone, like SSK Python.

## What it does

One tap on **Enable** starts streaming this phone's microphone to
the receiver on Taylor's member server: the app records 10-second
chunks (AAC in .m4a) and posts each one to

    https://members.911transedu.net/members/stream/upload?session=<id>&seq=<n>&ext=m4a

— the server's original upload protocol, open access, exactly the
receiver that already runs there. **Stop** ends the session. The
only prompt in the flow is iOS's own microphone permission, asked
once inside the app. There is no browser and no Safari pop-out:
that was the point of building it as an app.

Each Enable starts a fresh session (`app-…` id); chunks land on the
server under that session, and Jasmine can pull a session's audio
or a transcript on request.

## Layout

- `src/streammic/app.py` — the Toga screen (Enable/Stop + status).
- `src/streammic/streamcore.py` — the streaming loop (pure logic,
  unit-tested with fakes).
- `src/streammic/recorder.py` — the iOS microphone bridge
  (AVAudioRecorder via rubicon-objc; the only iOS-touching module).
- `src/streammic/uploader.py` — the server upload (pure stdlib).
- `tests/` — pytest suite for the pure parts.

## Building for the iPhone (Mac side)

Packaging follows Taylor's Python iOS Deployment Checklist, the
same path as SSK Python — these steps run on the Mac with Xcode:

1. `briefcase create iOS`
2. `briefcase build iOS`
3. `briefcase run iOS` (or open the generated Xcode project to sign
   and install / send to TestFlight with Taylor's Apple account).

The Python is verified here (unit tests + compile); the signed iOS
build itself is Mac-side, like SSK Python's phases.
