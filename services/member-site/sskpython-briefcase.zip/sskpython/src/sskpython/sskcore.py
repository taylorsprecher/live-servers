"""SSK Python — network scan core (no GUI imports, stdlib only).

Adapted from ssk_python.py (built 2026-11-22) for on-device use:
the phone is on the home Wi-Fi itself, so all probes are direct
sockets on the phone's own subnet — no tunnel, no computer.

The core finds the SSK portable cloud drive by what makes it the
SSK: its web UI (port 80 — the page is fetched and its title,
Server header and body are searched for SSK markers), its FTP
greeting banner (port 21), and SMB file-sharing presence (445).

iOS note: the app needs the Local Network permission for these
probes (the Info.plist NSLocalNetworkUsageDescription entry is set
at the Xcode phase of the deployment checklist). Without it, iOS
blocks the connections and every probe reads as "nothing answered".
"""

import re
import socket
from concurrent.futures import ThreadPoolExecutor

TIMEOUT = 2.5
SSK_MARKERS = ("sskcloud", "ssk cloud", "ssk")
CHECK_PORTS = (80, 21, 445)


def parse_title(html):
    m = re.search(r"<title[^>]*>(.*?)</title>", html or "",
                  re.IGNORECASE | re.DOTALL)
    if not m:
        return ""
    return re.sub(r"\s+", " ", m.group(1)).strip()


def identify_ssk(evidence):
    """Score one host's evidence. Returns (is_candidate, reasons).
    evidence: dict with optional http (fetch_http result),
    ftp_banner, smb_open."""
    reasons = []
    http = evidence.get("http")
    if http:
        haystack = " ".join([http.get("title", ""), http.get("server", ""),
                             http.get("body_head", "")]).lower()
        for marker in SSK_MARKERS:
            if marker in haystack:
                reasons.append(
                    f"web UI mentions '{marker}' "
                    f"(title: '{http.get('title', '')}', "
                    f"server: '{http.get('server', '')}')")
                break
    banner = (evidence.get("ftp_banner") or "").lower()
    if any(m in banner for m in SSK_MARKERS):
        reasons.append(f"FTP banner mentions SSK: "
                       f"'{evidence.get('ftp_banner', '')}'")
    return (bool(reasons), reasons)


def local_subnet_prefix():
    """The /24 prefix of the network this device is on, learned
    from the source address of a UDP 'connection' (no packet is
    sent). Falls back to the known home prefix."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
        finally:
            s.close()
        parts = ip.split(".")
        if len(parts) == 4 and parts[0] not in ("127", "0"):
            return ".".join(parts[:3]) + "."
    except OSError:
        pass
    return "192.168.0."


def _open(host, port):
    try:
        return socket.create_connection((host, port), timeout=TIMEOUT)
    except OSError:
        return None


def port_open(host, port):
    s = _open(host, port)
    if s is None:
        return False
    s.close()
    return True


def fetch_http(host, port=80):
    """One HTTP GET. Returns dict(status, server, title, body_head)
    or None when nothing HTTP answers."""
    s = _open(host, port)
    if s is None:
        return None
    try:
        s.settimeout(TIMEOUT)
        s.sendall((f"GET / HTTP/1.0\r\nHost: {host}\r\n"
                   f"User-Agent: SSKPython\r\n\r\n").encode())
        buf = b""
        while len(buf) < 16384:
            chunk = s.recv(4096)
            if not chunk:
                break
            buf += chunk
    except OSError:
        return None
    finally:
        try:
            s.close()
        except OSError:
            pass
    if not buf:
        return None
    head, _, body = buf.partition(b"\r\n\r\n")
    head_text = head.decode("latin-1", "replace")
    body_text = body.decode("latin-1", "replace")
    server = ""
    for line in head_text.split("\r\n"):
        if line.lower().startswith("server:"):
            server = line.split(":", 1)[1].strip()
    return {"status": head_text.split("\r\n", 1)[0] if head_text else "",
            "server": server, "title": parse_title(body_text),
            "body_head": body_text[:2048]}


def read_banner(host, port):
    s = _open(host, port)
    if s is None:
        return ""
    try:
        s.settimeout(TIMEOUT)
        return s.recv(256).decode("latin-1", "replace").strip()
    except OSError:
        return ""
    finally:
        try:
            s.close()
        except OSError:
            pass


def deep_check(ip):
    ev = {"ip": ip}
    ev["http"] = fetch_http(ip, 80)
    ev["ftp_banner"] = read_banner(ip, 21)
    ev["ftp_open"] = bool(ev["ftp_banner"]) or port_open(ip, 21)
    ev["smb_open"] = port_open(ip, 445)
    return ev


def describe(ev):
    ip = ev["ip"]
    lines = [ip]
    http = ev.get("http")
    if http:
        lines.append(f"  web UI: {http['status']}"
                     + (f", title '{http['title']}'" if http["title"] else "")
                     + (f", server '{http['server']}'" if http["server"] else ""))
    if ev.get("ftp_open"):
        lines.append("  FTP: open"
                     + (f", banner '{ev['ftp_banner']}'" if ev.get("ftp_banner") else ""))
    if ev.get("smb_open"):
        lines.append("  SMB (file sharing): open")
    if not http and not ev.get("ftp_open") and not ev.get("smb_open"):
        lines.append("  nothing answered on 80 / 21 / 445")
    candidate, reasons = identify_ssk(ev)
    if candidate:
        lines.append("  LOOKS LIKE THE SSK — " + "; ".join(reasons))
    elif http or ev.get("ftp_open") or ev.get("smb_open"):
        lines.append("  answers, but no SSK marker in what it sent back")
    return "\n".join(lines), candidate


def scan_network():
    """Sweep this device's /24 for web UIs, deep-check everything
    that answers, and identify the SSK. Returns (report_text,
    found_bool)."""
    prefix = local_subnet_prefix()
    hosts = [f"{prefix}{i}" for i in range(1, 255)]

    def probe(ip):
        return ip, fetch_http(ip, 80)

    hits = []
    with ThreadPoolExecutor(max_workers=32) as pool:
        for ip, http in pool.map(probe, hosts):
            if http:
                hits.append(ip)

    lines = [f"Scanned {prefix}0/24 — {len(hits)} device(s) with a web UI.",
             ""]
    found = False
    for ip in hits:
        text, candidate = describe(deep_check(ip))
        lines.append(text)
        found = found or candidate
    if not hits:
        lines.append("No web UI answered anywhere on this network.")
    lines.append("")
    if found:
        lines.append(
            "Verdict: the SSK drive IS on this network (marked above). "
            "Open the SSKCloud app — it should find the drive now — or "
            "browse its files over SMB from the Files app.")
    else:
        lines.append(
            "Verdict: no SSK found on this network. It is off or "
            "asleep, on a different network, or in its own Wi-Fi "
            "access-point mode — check the Wi-Fi list for an "
            "'SSKCloud-...' network. Or run the disk-alive test: "
            "plug the drive into this iPhone by USB-C and look in "
            "Files > Browse; if it mounts there, the disk is alive.")
    return "\n".join(lines), found


def selftest():
    """Offline checks of the pure logic (no real sockets)."""
    assert parse_title("<html><TITLE>  SSKCloud\n Login </TITLE>") == "SSKCloud Login"
    assert parse_title("<p>no title</p>") == ""
    ev = {"http": {"title": "SSKCloud", "server": "mini_httpd",
                   "body_head": "<p>welcome</p>"},
          "ftp_banner": "", "smb_open": True}
    ok, reasons = identify_ssk(ev)
    assert ok and reasons
    ev2 = {"http": {"title": "Router Admin", "server": "nginx",
                    "body_head": "<p>hello</p>"},
           "ftp_banner": "220 FTP ready", "smb_open": False}
    ok2, _ = identify_ssk(ev2)
    assert not ok2
    text, cand = describe({"ip": "192.168.0.99", "http": None,
                           "ftp_banner": "", "ftp_open": False,
                           "smb_open": False})
    assert not cand and "nothing answered" in text
    print("sskcore selftest: all checks passed")


if __name__ == "__main__":
    selftest()
