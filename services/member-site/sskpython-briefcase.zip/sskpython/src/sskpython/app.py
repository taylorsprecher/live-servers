"""SSK Python — find the SSK portable cloud drive from the phone.

A Toga front-end over sskcore: one button sweeps the Wi-Fi network
the phone is on for the drive's web UI / FTP / SMB services and
shows the plain verdict. The USB-C disk-alive steps are on the
same screen, because the network hunt and the cable test are the
two halves of the same job (Taylor's direction, 2026-11-22:
no computer — the phone does both).
"""

import threading

import toga
from toga.style.pack import COLUMN, PACK

from . import sskcore

USB_STEPS = (
    "Disk-alive test (USB-C, no computer):\n"
    "1. Plug the SSK drive into this iPhone with a USB-C cable.\n"
    "2. Open Files > Browse and look under Locations.\n"
    "3. If the drive appears, the disk is alive and its files are "
    "right there.\n"
    "4. If nothing appears, note whether the drive's light came on "
    "or it spun up — that says which way it failed."
)


class SSKPython(toga.App):
    def startup(self):
        self.output = toga.MultilineTextInput(
            readonly=True,
            value=(
                "SSK Python finds the SSK portable cloud drive on "
                "this Wi-Fi network.\n\nTap the button to hunt for "
                "it. The app needs Local Network permission — if "
                "asked, allow it.\n\n" + USB_STEPS
            ),
            style=PACK(flex=1),
        )
        self.scan_button = toga.Button(
            "Find the SSK drive",
            on_press=self.run_scan,
            style=PACK(padding=10),
        )
        main_box = toga.Box(
            children=[self.scan_button, self.output],
            style=PACK(direction=COLUMN, padding=10, flex=1),
        )
        self.main_window = toga.MainWindow(title=self.formal_name)
        self.main_window.content = main_box
        self.main_window.show()

    def run_scan(self, widget):
        self.scan_button.enabled = False
        self.output.value = "Hunting for the SSK drive on this network..."

        def work():
            try:
                report, _found = sskcore.scan_network()
            except Exception as exc:  # keep the verdict plain, never crash
                report = f"The hunt failed: {exc}"
            self.output.value = report
            self.scan_button.enabled = True

        threading.Thread(target=work, daemon=True).start()


def main():
    return SSKPython()
