"""Tests for the SSK scan core — pure logic, no network, no GUI."""

from sskpython import sskcore


def test_parse_title():
    assert sskcore.parse_title(
        "<html><TITLE>  SSKCloud\n Login </TITLE>") == "SSKCloud Login"
    assert sskcore.parse_title("<p>no title</p>") == ""


def test_identify_ssk_by_web_ui():
    ev = {"http": {"title": "SSKCloud", "server": "mini_httpd",
                   "body_head": "<p>welcome</p>"},
          "ftp_banner": "", "smb_open": True}
    ok, reasons = sskcore.identify_ssk(ev)
    assert ok and reasons


def test_identify_rejects_router():
    ev = {"http": {"title": "Router Admin", "server": "nginx",
                   "body_head": "<p>hello</p>"},
          "ftp_banner": "220 FTP ready", "smb_open": False}
    ok, _ = sskcore.identify_ssk(ev)
    assert not ok


def test_identify_ssk_by_ftp_banner():
    ev = {"http": None, "ftp_banner": "220 SSK FTP service",
          "smb_open": False}
    ok, _ = sskcore.identify_ssk(ev)
    assert ok


def test_describe_silent_host():
    text, cand = sskcore.describe(
        {"ip": "192.168.0.99", "http": None, "ftp_banner": "",
         "ftp_open": False, "smb_open": False})
    assert not cand and "nothing answered" in text
