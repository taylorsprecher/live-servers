# SSK Python

Find Taylor's SSK portable cloud drive from the iPhone — no computer.

SSK Python sweeps the Wi-Fi network the phone is on for the drive's
web UI (port 80, identified by its SSK markers), FTP banner (21) and
SMB file sharing (445), and gives a plain verdict. The same screen
carries the USB-C disk-alive test: plug the drive into the iPhone,
open Files > Browse, and see whether the disk mounts.

Built 2026-11-22 from `ssk_python.py` at Taylor's direction, packaged
with BeeWare Briefcase following Taylor's **Python iOS Deployment
Checklist** (filed 2026-11-22; built from the Python iOS guide filed
2026-11-04). The project also lives on the member site:
https://members.911transedu.net/members/ssk

## Checklist status (2026-11-22)

- Phase 1 — Development environment: **done** (Briefcase 0.4.7 venv;
  the on-Mac Python install happens again on the Mac at Phase 4).
- Phase 2 — Create project: **done** (`briefcase new`; formal name
  "SSK Python", app `sskpython`, bundle `net.911transedu.sskpython`,
  GUI framework Toga).
- Phase 3 — Configure dependencies: **done** (stdlib-only scan core;
  Toga per-platform requirements in pyproject.toml; the iOS
  `NSLocalNetworkUsageDescription` entry is set — the app cannot
  probe the local network without that permission prompt).
- Phases 4–12 — **Mac-side, Taylor's steps**: `briefcase create iOS`,
  simulator + physical iPhone runs, Xcode signing with Taylor's
  Apple Developer Team, App Store Connect, archive, TestFlight
  upload and distribution. These cannot run on Jasmine's Linux VM
  (Xcode is macOS-only) and need Taylor's Apple Developer account.

## Layout

- `src/sskpython/sskcore.py` — the scan core (stdlib only, no GUI
  imports; `python -m sskpython.sskcore` runs its offline selftest).
- `src/sskpython/app.py` — the Toga front-end.
- `tests/test_sskcore.py` — the core's logic tests (5 passing,
  2026-11-22).
