"""Dockerized Core Lightning upgrade workflow — custom plugins, strict pre-flight.

Adapted workflow pasted by Taylor, 2026-11-26, tailored for a Dockerized
CLN deployment with custom (non-reckless) plugins. Reviewed line by line
by Jasmine on receipt; the pure pieces (validate_custom_plugins,
check_disk_space, capture_state, verify_upgrade, backup_host_volumes,
deploy_custom_plugins) are unit-tested against stubs/temp dirs. main()
is NOT run here — no Dockerized lightningd exists in Taylor's fleet
inventory, and its docker compose stop/pull/up steps belong on the
node's own host after a regtest dry run.

Jasmine review notes (code unchanged):
* The description Taylor pasted with this workflow overstates two
  things the code does not do: there is no docker exec fallback for RPC
  (the RPC is the bind-mounted socket only), and there is no AUTOMATIC
  rollback — on verification failure the workflow logs "Manual
  intervention required", names the previous image, warns against
  restoring the old database, and exits 1. Rollback is a manual step.
* `import os` is unused — harmless.
* The database guardrail from Taylor's notes stands: even in Docker, if
  the upgraded container started and connected to peers, do NOT
  overwrite lightningd.sqlite3 with the pre-upgrade copy; roll back only
  plugin files or the image, and only if the schema permits.

    pip install pyln-client
    python3 cln_docker_upgrade.py \
      --container cln \
      --compose-file /opt/lightning/docker-compose.yml \
      --compose-service lightningd \
      --lightning-dir /opt/lightning/data/bitcoin \
      --rpc /opt/lightning/data/bitcoin/lightning-rpc \
      --custom-plugins-dir /opt/lightning/plugins \
      --plugin-staging-dir /opt/lightning/plugins_staging \
      --expected-plugins fee_adjuster.py rebalance_custom.py \
      --backup-dir /mnt/backups/cln \
      --min-free-gb 10
"""

import argparse
import json
import os
import shutil
import stat
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

from pyln.client import LightningRpc


def log(msg: str, level: str = "INFO") -> None:
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    print(f"[{ts}] [{level}] {msg}")


def run_cmd(cmd: list[str], check: bool = True) -> subprocess.CompletedProcess:
    log(f"Running: {' '.join(cmd)}")
    proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
    if proc.stdout.strip():
        log(proc.stdout.strip())
    if proc.returncode != 0:
        if proc.stderr.strip():
            log(proc.stderr.strip(), level="ERROR")
        if check:
            raise subprocess.CalledProcessError(proc.returncode, cmd, proc.stdout, proc.stderr)
    return proc


def check_disk_space(target_dir: Path, required_gb: float) -> None:
    target_dir.mkdir(parents=True, exist_ok=True)
    usage = shutil.disk_usage(target_dir)
    free_gb = usage.free / (1024 ** 3)
    if free_gb < required_gb:
        raise RuntimeError(
            f"Insufficient disk space at {target_dir}: {free_gb:.2f} GB free, {required_gb:.2f} GB required."
        )
    log(f"Disk space check passed: {free_gb:.2f} GB available at {target_dir}")


def check_docker_container(container: str) -> str:
    proc = run_cmd(["docker", "inspect", "-f", "{{.State.Running}}|{{.Config.Image}}", container])
    running_str, image_name = proc.stdout.strip().split("|", 1)
    if running_str.lower() != "true":
        raise RuntimeError(f"Container '{container}' is not running (State.Running={running_str}).")
    log(f"Container '{container}' is running image '{image_name}'")
    return image_name


def validate_custom_plugins(plugin_files: list[Path]) -> None:
    """Ensure custom plugins exist on host, are executable, and have a valid shebang."""
    for p in plugin_files:
        if not p.is_file():
            raise FileNotFoundError(f"Custom plugin not found: {p}")
        mode = p.stat().st_mode
        if not (mode & stat.S_IXUSR):
            raise PermissionError(f"Custom plugin is not executable (chmod +x required): {p}")
        first_line = p.read_text(encoding="utf-8", errors="replace").splitlines()[0]
        if not first_line.startswith("#!"):
            raise ValueError(f"Custom plugin missing shebang (#!...) on line 1: {p}")
    log(f"Validated {len(plugin_files)} custom plugin binary/script file(s)")


def preflight_checks(
    rpc: LightningRpc,
    container: str,
    backup_dir: Path,
    min_free_gb: float,
    allow_pending_htlcs: bool,
    custom_plugin_targets: list[Path],
) -> tuple[dict, str]:
    log("Starting strict pre-flight checks...")
    current_image = check_docker_container(container)
    check_disk_space(backup_dir, min_free_gb)
    validate_custom_plugins(custom_plugin_targets)

    info = rpc.getinfo()
    # Check for sync warnings in getinfo
    warnings = {k: v for k, v in info.items() if k.startswith("warning_")}
    if warnings:
        raise RuntimeError(f"Node reported active warnings in getinfo: {warnings}")

    funds = rpc.listfunds()
    channels = funds.get("channels", [])
    unhealthy_states = {
        c.get("channel_id"): c.get("state")
        for c in channels
        if c.get("state") not in {"CHANNELD_NORMAL", "CHANNELD_AWAITING_LOCKIN", "ONCHAIN"}
    }
    if unhealthy_states:
        raise RuntimeError(f"Channels in transitional/closing states detected: {unhealthy_states}")

    if not allow_pending_htlcs:
        peers = rpc.listpeers().get("peers", [])
        pending = []
        for peer in peers:
            for ch in peer.get("channels", []):
                htlcs = ch.get("htlcs", [])
                if htlcs:
                    pending.append((peer.get("id"), ch.get("channel_id"), len(htlcs)))
        if pending:
            raise RuntimeError(f"Active pending HTLCs detected (rerun with --allow-pending-htlcs to override): {pending}")

    log("All pre-flight checks passed.")
    return info, current_image


def capture_state(rpc: LightningRpc, out_file: Path) -> dict:
    info = rpc.getinfo()
    funds = rpc.listfunds()
    peers = rpc.listpeers()
    plugins = rpc.plugin("list")

    channels = funds.get("channels", [])
    active_channels = [c for c in channels if c.get("state") == "CHANNELD_NORMAL"]

    state = {
        "captured_at": datetime.now(timezone.utc).isoformat(),
        "id": info.get("id"),
        "version": info.get("version"),
        "network": info.get("network"),
        "blockheight": info.get("blockheight"),
        "total_channels": len(channels),
        "active_channels": len(active_channels),
        "plugins": plugins.get("plugins", []),
    }
    out_file.write_text(json.dumps(state, indent=2), encoding="utf-8")
    return state


def backup_host_volumes(lightning_dir: Path, custom_plugins_dir: Path, backup_dest: Path) -> None:
    """Cold backup of bind-mounted CLN data and custom plugins while container is stopped."""
    backup_dest.mkdir(parents=True, exist_ok=True)
    critical_files = [
        "lightningd.sqlite3",
        "lightningd.sqlite3-wal",
        "lightningd.sqlite3-shm",
        "hsm_secret",
        "emergency.recover",
        "config",
    ]
    for fname in critical_files:
        src = lightning_dir / fname
        if src.exists():
            shutil.copy2(src, backup_dest / fname)
            log(f"Backed up {fname}")

    if custom_plugins_dir.is_dir():
        shutil.copytree(custom_plugins_dir, backup_dest / "custom_plugins", symlinks=True, dirs_exist_ok=True)
        log(f"Backed up custom plugins directory: {custom_plugins_dir}")


def deploy_custom_plugins(
    staging_dir: Path | None,
    custom_plugins_dir: Path,
    venv_pip: Path | None,
) -> None:
    """Sync updated custom plugins from staging into the mounted plugins dir and install requirements."""
    if staging_dir is None:
        return
    if not staging_dir.is_dir():
        raise FileNotFoundError(f"Plugin staging directory does not exist: {staging_dir}")

    custom_plugins_dir.mkdir(parents=True, exist_ok=True)
    for item in staging_dir.iterdir():
        dest = custom_plugins_dir / item.name
        if item.is_dir():
            shutil.copytree(item, dest, symlinks=True, dirs_exist_ok=True)
        else:
            shutil.copy2(item, dest)
            # Preserve/ensure executable bit on plugin entrypoints
            if item.suffix in {".py", ".sh", ""}:
                dest.chmod(dest.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    log(f"Synced custom plugins from {staging_dir} to {custom_plugins_dir}")

    req_file = custom_plugins_dir / "requirements.txt"
    if venv_pip and req_file.is_file():
        run_cmd([str(venv_pip), "install", "--upgrade", "-r", str(req_file)])


def wait_for_rpc(rpc_path: Path, container: str, timeout_sec: int = 90) -> LightningRpc:
    deadline = time.monotonic() + timeout_sec
    last_err = None
    while time.monotonic() < deadline:
        # Ensure container didn't crash-loop
        proc = run_cmd(["docker", "inspect", "-f", "{{.State.Running}}", container], check=False)
        if proc.stdout.strip().lower() != "true":
            logs = run_cmd(["docker", "logs", "--tail", "30", container], check=False)
            raise RuntimeError(f"Container '{container}' exited during startup:\n{logs.stdout}\n{logs.stderr}")

        if rpc_path.exists():
            try:
                rpc = LightningRpc(str(rpc_path))
                rpc.getinfo()
                return rpc
            except Exception as exc:
                last_err = exc
        time.sleep(2.0)
    raise TimeoutError(f"Timed out waiting for RPC at {rpc_path}: {last_err}")


def verify_upgrade(pre: dict, post: dict, expected_plugins: list[str]) -> list[str]:
    issues: list[str] = []
    if pre.get("id") != post.get("id"):
        issues.append(f"Node ID mismatch: pre={pre.get('id')} post={post.get('id')}")
    if post.get("blockheight", 0) < pre.get("blockheight", 0):
        issues.append(f"Blockheight regressed: pre={pre.get('blockheight')} post={post.get('blockheight')}")
    if post.get("active_channels", 0) < pre.get("active_channels", 0):
        issues.append(
            f"Active channels dropped: pre={pre.get('active_channels')} post={post.get('active_channels')}"
        )

    loaded_names = {Path(p.get("name", "")).name for p in post.get("plugins", [])}
    active_map = {Path(p.get("name", "")).name: p.get("active", True) for p in post.get("plugins", [])}
    for req in expected_plugins:
        name = Path(req).name
        if name not in loaded_names:
            issues.append(f"Expected custom plugin not loaded: {name}")
        elif not active_map.get(name, True):
            issues.append(f"Custom plugin loaded but inactive: {name}")
    return issues


def main() -> None:
    parser = argparse.ArgumentParser(description="Dockerized Core Lightning + Custom Plugins Upgrade Workflow")
    parser.add_argument("--container", required=True, help="Docker container name (e.g. cln)")
    parser.add_argument("--compose-file", type=Path, required=True, help="Path to docker-compose.yml")
    parser.add_argument("--compose-service", default="lightningd", help="Service name in docker-compose.yml")
    parser.add_argument("--lightning-dir", type=Path, required=True, help="Host bind-mounted network dir (e.g. /data/cln/bitcoin)")
    parser.add_argument("--rpc", type=Path, required=True, help="Host path to bind-mounted lightning-rpc socket")
    parser.add_argument("--custom-plugins-dir", type=Path, required=True, help="Host bind-mounted custom plugins dir")
    parser.add_argument("--plugin-staging-dir", type=Path, default=None, help="Optional staging dir with updated custom plugins")
    parser.add_argument("--plugin-venv-pip", type=Path, default=None, help="Optional host pip path for plugin virtualenv")
    parser.add_argument("--expected-plugins", nargs="*", default=[], help="Filenames of expected active plugins")
    parser.add_argument("--backup-dir", type=Path, required=True, help="Host backup destination directory")
    parser.add_argument("--min-free-gb", type=float, default=5.0, help="Minimum free GB required for backup")
    parser.add_argument("--allow-pending-htlcs", action="store_true", help="Proceed even if channels have active HTLCs")
    args = parser.parse_args()

    run_id = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    session_dir = args.backup_dir / f"docker_upgrade_{run_id}"
    session_dir.mkdir(parents=True, exist_ok=True)

    rpc = LightningRpc(str(args.rpc))
    expected_paths = [args.custom_plugins_dir / p for p in args.expected_plugins]

    # 1. Strict pre-flight checks
    _, previous_image = preflight_checks(
        rpc=rpc,
        container=args.container,
        backup_dir=args.backup_dir,
        min_free_gb=args.min_free_gb,
        allow_pending_htlcs=args.allow_pending_htlcs,
        custom_plugin_targets=expected_paths if args.plugin_staging_dir is None else [],
    )
    pre_state = capture_state(rpc, session_dir / "pre_upgrade_state.json")
    log(f"Pre-upgrade CLN {pre_state.get('version')} | Active channels: {pre_state.get('active_channels')}")

    # 2. Stop container cleanly and take cold host-volume backup
    run_cmd(["docker", "compose", "-f", str(args.compose_file), "stop", args.compose_service])
    backup_host_volumes(args.lightning_dir, args.custom_plugins_dir, session_dir / "cold_backup")

    # 3. Deploy updated custom plugins & pull/recreate upgraded container
    deploy_custom_plugins(args.plugin_staging_dir, args.custom_plugins_dir, args.plugin_venv_pip)
    if args.expected_plugins:
        validate_custom_plugins([args.custom_plugins_dir / p for p in args.expected_plugins])

    run_cmd(["docker", "compose", "-f", str(args.compose_file), "pull", args.compose_service])
    run_cmd(["docker", "compose", "-f", str(args.compose_file), "up", "-d", args.compose_service])

    # 4. Wait for RPC and verify
    post_rpc = wait_for_rpc(args.rpc, args.container, timeout_sec=120)
    post_state = capture_state(post_rpc, session_dir / "post_upgrade_state.json")
    log(f"Post-upgrade CLN {post_state.get('version')} | Active channels: {post_state.get('active_channels')}")

    issues = verify_upgrade(pre_state, post_state, args.expected_plugins)
    if issues:
        log("POST-UPGRADE VERIFICATION FAILED:", level="ERROR")
        for issue in issues:
            log(f"  - {issue}", level="ERROR")
        log(
            f"Manual intervention required. Previous image was '{previous_image}'. "
            "DO NOT restore old SQLite DB if channels were active after restart.",
            level="WARN",
        )
        sys.exit(1)

    log(f"Dockerized CLN & custom plugins upgrade succeeded. Artifacts: {session_dir}")


if __name__ == "__main__":
    main()
