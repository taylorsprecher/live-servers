"""Cport-Lightening 1/3 — Hardware / Firmware Upgrade (Serial / COM Port).

Starter build pasted by Taylor, 2026-11-26 (all three interpretations of
Cport-Lightening). Reviewed line by line by Jasmine on receipt; protocol
verified against a fake device over a PTY pair (READY / ACK:<n> / COMMIT).

Sends a firmware image over a serial/COM port with pyserial: handshake
header carries size, chunk count and SHA-256; each chunk waits for its
ACK:<idx> line; COMMIT finalizes and the device reports its status.

    pip install pyserial
    python3 cport_lightning_serial_upgrade.py --port /dev/ttyUSB0 \
        --baud 115200 --file firmware.bin
"""

import argparse
import hashlib
import time
from pathlib import Path

import serial


def upgrade_firmware(port: str, baudrate: int, firmware_path: Path, chunk_size: int = 1024) -> None:
    if not firmware_path.is_file():
        raise FileNotFoundError(f"Firmware file not found: {firmware_path}")

    data = firmware_path.read_bytes()
    sha256 = hashlib.sha256(data).hexdigest()
    total_chunks = (len(data) + chunk_size - 1) // chunk_size

    print(f"Target: {port} @ {baudrate} bps | Size: {len(data)} bytes | Chunks: {total_chunks}")
    print(f"SHA-256: {sha256}")

    with serial.Serial(port=port, baudrate=baudrate, timeout=3) as ser:
        time.sleep(0.2)
        ser.reset_input_buffer()
        ser.reset_output_buffer()

        # Handshake / upgrade header
        header = f"UPGRADE:{len(data)}:{total_chunks}:{sha256}\n".encode("utf-8")
        ser.write(header)
        resp = ser.readline().decode("utf-8", errors="replace").strip()
        if resp != "READY":
            raise RuntimeError(f"Device did not enter upgrade mode. Response: {resp!r}")

        # Stream firmware chunks
        for idx in range(total_chunks):
            start = idx * chunk_size
            end = start + chunk_size
            chunk = data[start:end]

            ser.write(chunk)
            ack = ser.readline().decode("utf-8", errors="replace").strip()
            if ack != f"ACK:{idx}":
                raise RuntimeError(f"Chunk {idx} failed. Expected ACK:{idx}, got {ack!r}")

            if (idx + 1) % 10 == 0 or idx + 1 == total_chunks:
                pct = ((idx + 1) / total_chunks) * 100
                print(f"Progress: {idx + 1}/{total_chunks} ({pct:.1f}%)")

        # Finalize and reboot
        ser.write(b"COMMIT\n")
        final_resp = ser.readline().decode("utf-8", errors="replace").strip()
        print(f"Device final status: {final_resp}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Serial firmware upgrade utility")
    parser.add_argument("--port", required=True, help="Serial port (e.g., /dev/ttyUSB0 or COM3)")
    parser.add_argument("--baud", type=int, default=115200, help="Baud rate")
    parser.add_argument("--file", type=Path, required=True, help="Path to firmware binary")
    args = parser.parse_args()
    upgrade_firmware(args.port, args.baud, args.file)
