# Cport-Lightening — Python build set

Five Python scripts from Taylor's Cport-Lightening builds (pasted
2026-11-26, reviewed line by line, installed and verified the same
day). Three interpretations of "Cport-Lightening", plus the complete
Core Lightning upgrade workflow and its Dockerized variant.

## Contents

| File | What it is |
|---|---|
| `cport_lightning_serial_upgrade.py` | Hardware/firmware upgrade over a serial/COM port (pyserial): UPGRADE header with size, chunk count and SHA-256; every chunk waits for `ACK:<n>`; `COMMIT` finalizes. |
| `cport_lightning_pytorch_upgrade.py` | PyTorch Lightning pattern for porting/upgrading a model: a `LightningModule` classifier with clean training/validation/logging, fit on synthetic data. |
| `cport_lightning_cln_upgrade.py` | Small Core Lightning helper (pyln-client): pre/post snapshots around a `systemctl restart`. Superseded for real use by the workflow below. |
| `cln_upgrade_workflow.py` | Complete Core Lightning upgrade workflow: state capture → clean stop → cold backup → upgrade → optional reckless plugin reinstall → restart → verification. |
| `cln_docker_upgrade.py` | The same job for a Dockerized CLN with custom (non-reckless) plugins: strict pre-flight checks, host-volume cold backup, staged plugin deploy, compose pull/up, verification. |
| `tests_run.py` | Jasmine's verification battery (PTY fake device, stub RPCs, temp dirs). Not part of the tools; kept so the checks can be re-run. |

## Install

```sh
python3 -m venv .venvs/cportlightening
.venvs/cportlightening/bin/pip install pyserial pyln-client
# only for the PyTorch script (CPU build):
.venvs/cportlightening/bin/pip install torch --index-url https://download.pytorch.org/whl/cpu
.venvs/cportlightening/bin/pip install lightning
```

Note (learned 2026-11-26): pip unpacks wheels in the temp dir — on a
host where /tmp is small, point `TMPDIR` at a roomy directory first or
large wheels fail with "No space left on device".

## Run

```sh
# Serial firmware upgrade
python3 cport_lightning_serial_upgrade.py --port /dev/ttyUSB0 --baud 115200 --file firmware.bin

# PyTorch Lightning pattern (trains 5 epochs on synthetic data)
python3 cport_lightning_pytorch_upgrade.py

# Core Lightning upgrade (ON THE NODE'S HOST, after a regtest dry run)
python3 cln_upgrade_workflow.py \
  --lightning-dir "$HOME/.lightning/bitcoin" \
  --rpc "$HOME/.lightning/bitcoin/lightning-rpc" \
  --backup-dir "/mnt/backup/cln" \
  --upgrade-cmd sudo apt-get install -y lightningd

# Dockerized variant
python3 cln_docker_upgrade.py \
  --container cln --compose-file /opt/lightning/docker-compose.yml \
  --lightning-dir /opt/lightning/data/bitcoin \
  --rpc /opt/lightning/data/bitcoin/lightning-rpc \
  --custom-plugins-dir /opt/lightning/plugins \
  --backup-dir /mnt/backups/cln
```

## Critical safety rules for the CLN workflows (Taylor's, kept verbatim in spirit)

- **Never restore a stale channel database.** Putting an older
  `lightningd.sqlite3` back online after channel activity can trigger
  a force-close penalty and loss of channel funds. Always stop
  lightningd cleanly before a cold backup — and after an upgraded node
  has started and connected to peers, do not roll the database back at
  all; roll back only plugin files or the image, if the schema permits.
- **Preserve `hsm_secret` and `emergency.recover`** offline, plus any
  HSM passphrase.
- **Upgrades are often one-way** (schema migrations); archive the
  pre-upgrade snapshot and old binaries/configs.
- **Dry-run on regtest/signet first.**

## Verification (2026-11-26, Jasmine)

- Serial upgrader: full transfer against a fake device on a PTY pair —
  2,500-byte payload byte-identical, SHA-256 matched, COMMIT → DONE:OK.
- Both CLN workflows: capture/verify/backup/plugin-validation pieces
  passed against stub RPCs and temp dirs (battery: 4/4).
- PyTorch script: trained end-to-end on CPU (torch 2.15.0+cpu,
  lightning 2.6.6), 5 epochs, clean exit. Validation accuracy is chance
  level by design — the data is random; the script is the pattern.
- Neither CLN `main()` was run: no lightningd node (bare or Docker)
  exists in the fleet yet.

## Review notes

- The Docker workflow's original description overstates the code:
  there is **no docker-exec RPC fallback** (bind-mounted socket only)
  and **no automatic rollback** — on verification failure it logs
  "Manual intervention required", names the previous image, and
  exits 1.
- `cln_upgrade_workflow.py --upgrade-cmd` takes ONE command with
  arguments (no shell), so `&&` chains do not work there — run
  `apt-get update` separately.
