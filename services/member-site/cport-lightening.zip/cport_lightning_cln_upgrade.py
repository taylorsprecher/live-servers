"""Cport-Lightening 3/3 — Core Lightning (c-lightning) Node Upgrade Helper.

Starter build pasted by Taylor, 2026-11-26 (all three interpretations of
Cport-Lightening). Reviewed line by line by Jasmine on receipt; the
snapshot half is unit-tested against a stub RPC. The full run needs a
real lightningd node (none in Taylor's fleet inventory as of 2026-11-26)
and restarts its systemd service between the pre/post snapshots.

Uses pyln-client to snapshot node info, channel and peer counts before
and after an upgrade restart, writing both snapshots as JSON.

    pip install pyln-client
    python3 cport_lightning_cln_upgrade.py --rpc /path/to/lightning-rpc
"""

import argparse
import json
import subprocess
from pathlib import Path

from pyln.client import LightningRpc


def snapshot_node(rpc: LightningRpc, out_path: Path) -> dict:
    info = rpc.getinfo()
    funds = rpc.listfunds()
    peers = rpc.listpeers()
    snapshot = {
        "id": info.get("id"),
        "version": info.get("version"),
        "blockheight": info.get("blockheight"),
        "channels_count": len(funds.get("channels", [])),
        "peers_count": len(peers.get("peers", [])),
    }
    out_path.write_text(json.dumps(snapshot, indent=2), encoding="utf-8")
    return snapshot


def run_upgrade(rpc_path: Path, snapshot_dir: Path, service_name: str = "lightningd") -> None:
    snapshot_dir.mkdir(parents=True, exist_ok=True)
    rpc = LightningRpc(str(rpc_path))

    pre = snapshot_node(rpc, snapshot_dir / "pre_upgrade.json")
    print("Pre-upgrade snapshot:", json.dumps(pre))

    # Example systemd restart after binary/package upgrade
    subprocess.run(["systemctl", "restart", service_name], check=True)

    post = snapshot_node(rpc, snapshot_dir / "post_upgrade.json")
    print("Post-upgrade snapshot:", json.dumps(post))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Core Lightning node upgrade check")
    parser.add_argument("--rpc", type=Path, required=True, help="Path to lightning-rpc socket")
    parser.add_argument("--out", type=Path, default=Path("./cln_upgrade_snapshots"), help="Snapshot output folder")
    parser.add_argument("--service", default="lightningd", help="Systemd service name")
    args = parser.parse_args()
    run_upgrade(args.rpc, args.out, args.service)
