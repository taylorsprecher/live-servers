"""Cport-Lightening 2/3 — PyTorch Lightning Upgrade (Porting / Upgrading a Model).

Starter build pasted by Taylor, 2026-11-26 (all three interpretations of
Cport-Lightening). Reviewed line by line by Jasmine on receipt.

Structures a small classifier as a LightningModule with clean training /
validation / logging, and fits it on synthetic data — the pattern for
porting or upgrading a PyTorch model onto the Lightning Trainer.

    pip install torch lightning
    python3 cport_lightning_pytorch_upgrade.py
"""

import lightning as L
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset


class UpgradedClassifier(L.LightningModule):
    def __init__(self, input_dim: int = 32, hidden_dim: int = 64, num_classes: int = 10, lr: float = 1e-3):
        super().__init__()
        self.save_hyperparameters()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, num_classes),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)

    def training_step(self, batch, batch_idx: int) -> torch.Tensor:
        x, y = batch
        logits = self(x)
        loss = F.cross_entropy(logits, y)
        self.log("train_loss", loss, prog_bar=True)
        return loss

    def validation_step(self, batch, batch_idx: int) -> None:
        x, y = batch
        logits = self(x)
        loss = F.cross_entropy(logits, y)
        acc = (logits.argmax(dim=-1) == y).float().mean()
        self.log_dict({"val_loss": loss, "val_acc": acc}, prog_bar=True)

    def configure_optimizers(self):
        return torch.optim.AdamW(self.parameters(), lr=self.hparams.lr)


def main() -> None:
    L.seed_everything(42)

    x_train = torch.randn(512, 32)
    y_train = torch.randint(0, 10, (512,))
    x_val = torch.randn(128, 32)
    y_val = torch.randint(0, 10, (128,))

    train_loader = DataLoader(TensorDataset(x_train, y_train), batch_size=32, shuffle=True)
    val_loader = DataLoader(TensorDataset(x_val, y_val), batch_size=64)

    model = UpgradedClassifier()
    trainer = L.Trainer(max_epochs=5, accelerator="auto", devices="auto")
    trainer.fit(model, train_dataloaders=train_loader, val_dataloaders=val_loader)


if __name__ == "__main__":
    main()
