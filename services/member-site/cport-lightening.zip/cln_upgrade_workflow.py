"""Core Lightning (lightningd) upgrade workflow — back up, upgrade, verify.

Complete workflow pasted by Taylor, 2026-11-26; supersedes the smaller
CLN helper in cport_lightning_cln_upgrade.py. Reviewed line by line by
Jasmine on receipt. The pure pieces (capture_state, verify_upgrade,
backup_node_files) are unit-tested against stubs/temp dirs; main() itself
is NOT run here — there is no lightningd node in Taylor's fleet
inventory, and its systemctl stop/start + upgrade command belong on the
node's own host, after a regtest dry run (see the tips Taylor pasted
with it, kept in the project notes).

Jasmine review notes (code unchanged):
* RpcError is imported but never used — harmless.
* --upgrade-cmd uses nargs="+", so it takes ONE command with arguments;
  the pasted example's "sudo apt-get update && sudo apt-get install ..."
  would pass "&&" as a literal argument (no shell is involved). Run the
  update separately, then pass a single install command.

Taylor's critical safety rules, pasted with the workflow:
* Never restore a stale channel database: putting an older
  lightningd.sqlite3 back online after channel activity can trigger a
  force-close penalty and loss of channel funds. Always stop lightningd
  cleanly before taking a cold database/file backup.
* Preserve hsm_secret and emergency.recover: keep an offline copy of
  hsm_secret (and any HSM passphrase) plus the latest emergency.recover
  static channel backup.
* Upgrades are often one-way: database schema migrations on upgrade are
  generally not reversible; keep the pre-upgrade snapshot and old
  binaries/configs archived.
* Plugins: with reckless, the workflow records installed plugins,
  reinstalls/updates them, and verifies they load after the restart.

    pip install pyln-client
    python3 cln_upgrade_workflow.py \
      --lightning-dir "$HOME/.lightning/bitcoin" \
      --rpc "$HOME/.lightning/bitcoin/lightning-rpc" \
      --backup-dir "/mnt/backup/cln" \
      --service lightningd \
      --upgrade-cmd sudo apt-get install -y lightningd \
      --reckless-plugins clboss \
      --expected-plugins clboss
"""

import argparse
import json
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

from pyln.client import LightningRpc, RpcError


def log(msg: str) -> None:
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    print(f"[{ts}] {msg}")


def capture_state(rpc: LightningRpc, out_file: Path) -> dict:
    info = rpc.getinfo()
    funds = rpc.listfunds()
    peers = rpc.listpeers()
    plugins = rpc.plugin("list")

    channels = funds.get("channels", [])
    active_channels = [c for c in channels if c.get("state") == "CHANNELD_NORMAL"]
    connected_peers = [p for p in peers.get("peers", []) if p.get("connected")]

    state = {
        "captured_at": datetime.now(timezone.utc).isoformat(),
        "id": info.get("id"),
        "alias": info.get("alias"),
        "version": info.get("version"),
        "network": info.get("network"),
        "blockheight": info.get("blockheight"),
        "total_channels": len(channels),
        "active_channels": len(active_channels),
        "total_peers": len(peers.get("peers", [])),
        "connected_peers": len(connected_peers),
        "onchain_outputs_count": len(funds.get("outputs", [])),
        "plugins": plugins.get("plugins", []),
        "channels_summary": [
            {
                "channel_id": c.get("channel_id"),
                "peer_id": c.get("peer_id"),
                "state": c.get("state"),
                "amount_msat": c.get("amount_msat"),
                "spendable_msat": c.get("spendable_msat"),
            }
            for c in channels
        ],
    }
    out_file.write_text(json.dumps(state, indent=2), encoding="utf-8")
    return state


def run_cmd(cmd: list[str]) -> str:
    log(f"Running: {' '.join(cmd)}")
    proc = subprocess.run(cmd, capture_output=True, text=True, check=True)
    if proc.stdout.strip():
        log(proc.stdout.strip())
    return proc.stdout


def wait_for_rpc(rpc_path: Path, timeout_sec: int = 60) -> LightningRpc:
    deadline = time.monotonic() + timeout_sec
    last_err = None
    while time.monotonic() < deadline:
        if rpc_path.exists():
            try:
                rpc = LightningRpc(str(rpc_path))
                rpc.getinfo()
                return rpc
            except Exception as exc:
                last_err = exc
        time.sleep(1.5)
    raise TimeoutError(f"Timed out waiting for RPC at {rpc_path}: {last_err}")


def backup_node_files(lightning_dir: Path, backup_dest: Path) -> None:
    """
    Requires lightningd to be STOPPED first so SQLite files are consistent.
    Copies key state files and config/plugins directory to backup_dest.
    """
    backup_dest.mkdir(parents=True, exist_ok=True)
    important_files = [
        "lightningd.sqlite3",
        "lightningd.sqlite3-wal",
        "lightningd.sqlite3-shm",
        "hsm_secret",
        "emergency.recover",
        "config",
    ]
    for fname in important_files:
        src = lightning_dir / fname
        if src.exists():
            shutil.copy2(src, backup_dest / fname)
            log(f"Backed up {fname}")

    plugins_dir = lightning_dir / "plugins"
    if plugins_dir.is_dir():
        shutil.copytree(plugins_dir, backup_dest / "plugins", symlinks=True, dirs_exist_ok=True)
        log("Backed up plugins directory")


def verify_upgrade(pre: dict, post: dict, expected_plugins: list[str]) -> list[str]:
    issues: list[str] = []

    if pre.get("id") != post.get("id"):
        issues.append(f"Node ID mismatch: pre={pre.get('id')} post={post.get('id')}")

    if post.get("blockheight", 0) < pre.get("blockheight", 0):
        issues.append(
            f"Blockheight regressed: pre={pre.get('blockheight')} post={post.get('blockheight')}"
        )

    if post.get("active_channels", 0) < pre.get("active_channels", 0):
        issues.append(
            f"Active channels decreased: pre={pre.get('active_channels')} post={post.get('active_channels')}"
        )

    loaded_names = {Path(p.get("name", "")).name for p in post.get("plugins", [])}
    loaded_paths = {Path(p.get("path", "")).name for p in post.get("plugins", [])}
    for req_plugin in expected_plugins:
        req_name = Path(req_plugin).name
        if req_name not in loaded_names and req_name not in loaded_paths:
            issues.append(f"Expected plugin not loaded after upgrade: {req_plugin}")

    return issues


def main() -> None:
    parser = argparse.ArgumentParser(description="Back up, upgrade, and verify Core Lightning & plugins")
    parser.add_argument("--lightning-dir", type=Path, required=True, help="Path to CLN network dir (e.g. ~/.lightning/bitcoin)")
    parser.add_argument("--rpc", type=Path, required=True, help="Path to lightning-rpc socket")
    parser.add_argument("--backup-dir", type=Path, required=True, help="External/safe directory for backups & snapshots")
    parser.add_argument("--service", default="lightningd", help="Systemd service name for lightningd")
    parser.add_argument("--upgrade-cmd", nargs="+", required=True, help="Command to upgrade CLN binary/package (e.g. apt install ... or make install)")
    parser.add_argument("--reckless-plugins", nargs="*", default=[], help="Optional reckless plugin names to update/reinstall")
    parser.add_argument("--expected-plugins", nargs="*", default=[], help="Plugin names/paths expected to be active post-upgrade")
    parser.add_argument("--skip-stop-start", action="store_true", help="Do not manage systemctl stop/start (if managed externally)")
    args = parser.parse_args()

    run_id = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    session_dir = args.backup_dir / f"upgrade_{run_id}"
    session_dir.mkdir(parents=True, exist_ok=True)

    # 1. Pre-upgrade snapshot while node is running
    rpc = LightningRpc(str(args.rpc))
    pre_state = capture_state(rpc, session_dir / "pre_upgrade_state.json")
    log(f"Pre-upgrade version: {pre_state.get('version')} | active_channels: {pre_state.get('active_channels')}")

    # 2. Stop lightningd cleanly and take cold backup
    if not args.skip_stop_start:
        run_cmd(["systemctl", "stop", args.service])
    backup_node_files(args.lightning_dir, session_dir / "cold_backup")

    # 3. Upgrade Core Lightning binary/package and optional reckless plugins
    run_cmd(args.upgrade_cmd)

    for plugin_name in args.reckless_plugins:
        # Reinstall/update via reckless if used
        run_cmd(["reckless", "-l", str(args.lightning_dir.parent), "install", plugin_name])

    # 4. Start lightningd and wait for RPC
    if not args.skip_stop_start:
        run_cmd(["systemctl", "start", args.service])

    post_rpc = wait_for_rpc(args.rpc, timeout_sec=90)
    post_state = capture_state(post_rpc, session_dir / "post_upgrade_state.json")
    log(f"Post-upgrade version: {post_state.get('version')} | active_channels: {post_state.get('active_channels')}")

    # 5. Verify node & plugin health
    issues = verify_upgrade(pre_state, post_state, args.expected_plugins)
    if issues:
        log("VERIFICATION WARNINGS/FAILURES DETECTED:")
        for item in issues:
            log(f"  - {item}")
        sys.exit(1)

    log(f"Upgrade verified successfully. Artifacts saved to: {session_dir}")


if __name__ == "__main__":
    main()
