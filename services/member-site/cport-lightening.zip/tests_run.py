"""Verification battery for Taylor's Cport-Lightening files (Jasmine, 2026-11-26).

- Serial upgrader: fake device on a PTY pair speaking READY / ACK:<n> / COMMIT.
- CLN helpers (both workflows): stub RPC objects + temp dirs.
Run with the cportlightening venv python. Prints PASS/FAIL per check.
"""

import hashlib
import io
import json
import os
import pty
import sys
import threading
from contextlib import redirect_stdout
from pathlib import Path

sys.path.insert(0, str(Path.home() / "workspace/user/files"))

RESULTS = []


def check(name, fn):
    try:
        fn()
        RESULTS.append((name, "PASS", ""))
        print(f"PASS  {name}")
    except Exception as exc:  # noqa: BLE001
        RESULTS.append((name, "FAIL", repr(exc)))
        print(f"FAIL  {name}: {exc!r}")


# ---------- 1. Serial firmware upgrader over a PTY ----------
def test_serial():
    import cport_lightning_serial_upgrade as upg

    fw = Path("/tmp/fw_test.bin")
    payload = bytes((i * 37 + 11) % 256 for i in range(2500))  # 3 chunks @1024
    fw.write_bytes(payload)
    want_sha = hashlib.sha256(payload).hexdigest()

    master, slave = pty.openpty()
    slave_name = os.ttyname(slave)
    received = bytearray()
    device_state = {}

    def device():
        buf = b""
        # header line
        while b"\n" not in buf:
            buf += os.read(master, 4096)
        header, buf = buf.split(b"\n", 1)
        parts = header.decode().strip().split(":")
        assert parts[0] == "UPGRADE", header
        total, chunks, sha = int(parts[1]), int(parts[2]), parts[3]
        device_state.update(total=total, chunks=chunks, sha=sha)
        os.write(master, b"READY\n")
        sizes = [1024] * (chunks - 1) + [total - 1024 * (chunks - 1)]
        for idx, size in enumerate(sizes):
            while len(buf) < size:
                buf += os.read(master, 4096)
            received.extend(buf[:size])
            buf = buf[size:]
            os.write(master, f"ACK:{idx}\n".encode())
        while b"\n" not in buf:
            buf += os.read(master, 4096)
        line, _ = buf.split(b"\n", 1)
        assert line.strip() == b"COMMIT", line
        os.write(master, b"DONE:OK\n")

    t = threading.Thread(target=device, daemon=True)
    t.start()
    out = io.StringIO()
    with redirect_stdout(out):
        upg.upgrade_firmware(slave_name, 115200, fw)
    t.join(timeout=5)
    assert device_state["sha"] == want_sha, device_state
    assert bytes(received) == payload, "payload mismatch"
    assert "Device final status: DONE:OK" in out.getvalue(), out.getvalue()
    os.close(master)
    os.close(slave)


# ---------- Shared stub RPC ----------
class StubRPC:
    def getinfo(self):
        return {"id": "node02abc", "alias": "testnode", "version": "v24.11",
                "network": "bitcoin", "blockheight": 870000}

    def listfunds(self):
        return {
            "channels": [
                {"channel_id": "ch1", "peer_id": "peer1", "state": "CHANNELD_NORMAL",
                 "amount_msat": 1000000, "spendable_msat": 900000},
                {"channel_id": "ch2", "peer_id": "peer2", "state": "ONCHAIN",
                 "amount_msat": 500000, "spendable_msat": 500000},
            ],
            "outputs": [{"txid": "x", "amount_msat": 12345}],
        }

    def listpeers(self):
        return {"peers": [{"id": "peer1", "connected": True, "channels": []},
                          {"id": "peer2", "connected": False, "channels": []}]}

    def plugin(self, sub):
        assert sub == "list"
        return {"plugins": [{"name": "/plugins/clboss", "path": "/plugins/clboss", "active": True}]}


# ---------- 2. Small CLN helper: snapshot_node ----------
def test_snapshot_node(tmp):
    import cport_lightning_cln_upgrade as small
    out = tmp / "snap.json"
    snap = small.snapshot_node(StubRPC(), out)
    assert snap["id"] == "node02abc" and snap["version"] == "v24.11"
    assert snap["blockheight"] == 870000
    assert snap["channels_count"] == 2 and snap["peers_count"] == 2
    assert json.loads(out.read_text()) == snap


# ---------- 3. Full workflow: capture_state / verify_upgrade / backup ----------
def test_workflow(tmp):
    import cln_upgrade_workflow as wf
    out = tmp / "state.json"
    st = wf.capture_state(StubRPC(), out)
    assert st["active_channels"] == 1 and st["total_channels"] == 2
    assert st["connected_peers"] == 1 and st["total_peers"] == 2
    assert st["onchain_outputs_count"] == 1
    assert st["channels_summary"][0]["channel_id"] == "ch1"

    assert wf.verify_upgrade(st, dict(st), ["clboss"]) == []
    bad = dict(st, blockheight=869999)
    issues = wf.verify_upgrade(st, bad, ["clboss"])
    assert any("Blockheight regressed" in i for i in issues), issues
    issues = wf.verify_upgrade(st, dict(st), ["nonexistent_plugin"])
    assert any("not loaded" in i for i in issues), issues

    ldir = tmp / "ln"
    (ldir / "plugins").mkdir(parents=True)
    (ldir / "lightningd.sqlite3").write_bytes(b"db")
    (ldir / "hsm_secret").write_bytes(b"secret")
    (ldir / "config").write_text("network=bitcoin")
    (ldir / "plugins" / "clboss").write_text("#!/usr/bin/env python3\n")
    dest = tmp / "backup"
    with redirect_stdout(io.StringIO()):
        wf.backup_node_files(ldir, dest)
    copied = sorted(p.name for p in dest.iterdir())
    assert copied == ["config", "hsm_secret", "lightningd.sqlite3", "plugins"], copied
    assert (dest / "plugins" / "clboss").exists()


# ---------- 4. Docker workflow pure pieces ----------
def test_docker(tmp):
    import cln_docker_upgrade as dk
    out = tmp / "dstate.json"
    st = dk.capture_state(StubRPC(), out)
    assert st["active_channels"] == 1 and st["total_channels"] == 2

    assert dk.verify_upgrade(st, dict(st), ["clboss"]) == []
    inactive = dict(st, plugins=[{"name": "/p/clboss", "active": False}])
    issues = dk.verify_upgrade(st, inactive, ["clboss"])
    assert any("inactive" in i for i in issues), issues

    good = tmp / "good.py"
    good.write_text("#!/usr/bin/env python3\nprint('hi')\n")
    good.chmod(0o755)
    dk.validate_custom_plugins([good])
    noexec = tmp / "noexec.py"
    noexec.write_text("#!/usr/bin/env python3\n")
    noexec.chmod(0o644)
    try:
        dk.validate_custom_plugins([noexec])
        raise AssertionError("non-executable plugin passed validation")
    except PermissionError:
        pass
    noshebang = tmp / "noshebang.py"
    noshebang.write_text("print('hi')\n")
    noshebang.chmod(0o755)
    try:
        dk.validate_custom_plugins([noshebang])
        raise AssertionError("shebang-less plugin passed validation")
    except ValueError:
        pass

    with redirect_stdout(io.StringIO()):
        dk.check_disk_space(tmp, 0.0001)
    try:
        dk.check_disk_space(tmp, 10_000_000.0)
        raise AssertionError("impossible disk requirement passed")
    except RuntimeError:
        pass

    ldir = tmp / "dln"
    plugdir = tmp / "dplugins"
    (ldir).mkdir()
    plugdir.mkdir()
    (ldir / "hsm_secret").write_bytes(b"s")
    (plugdir / "fee_adjuster.py").write_text("#!/usr/bin/env python3\n")
    dest = tmp / "dbackup"
    with redirect_stdout(io.StringIO()):
        dk.backup_host_volumes(ldir, plugdir, dest)
    assert (dest / "hsm_secret").exists()
    assert (dest / "custom_plugins" / "fee_adjuster.py").exists()

    staging = tmp / "staging"
    staging.mkdir()
    (staging / "newplug.py").write_text("#!/usr/bin/env python3\n")
    target = tmp / "target_plugins"
    with redirect_stdout(io.StringIO()):
        dk.deploy_custom_plugins(staging, target, None)
    deployed = target / "newplug.py"
    assert deployed.exists() and os.access(deployed, os.X_OK)


if __name__ == "__main__":
    import tempfile
    check("serial PTY protocol (READY/ACK/COMMIT, sha + payload)", test_serial)
    with tempfile.TemporaryDirectory() as td:
        tmp = Path(td)
        check("small CLN snapshot_node", lambda: test_snapshot_node(tmp))
        check("CLN workflow capture/verify/backup", lambda: test_workflow(tmp))
        check("Docker workflow pure pieces", lambda: test_docker(tmp))
    failed = [r for r in RESULTS if r[1] == "FAIL"]
    print(f"\n{len(RESULTS) - len(failed)}/{len(RESULTS)} checks passed")
    sys.exit(1 if failed else 0)
