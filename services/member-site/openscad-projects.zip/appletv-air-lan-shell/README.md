# Apple TV Air Drop-Jaw LAN Shell

Source document: **AppleTV Air LAN.docx** (Google Drive). Installed 2026-11-28.
Code extracted verbatim from the source document.

## Files

| File | Assembly |
|---|---|
| `appletv_air_lan_shell.scad` | Rounded outer enclosure shell with drop-jaw RJ45 expansion slot (helper module `rounded_cube`, top-level `difference()`) |

## Headline specs (as found in the source)

- Enclosure: 84.0 × 28.0 × 6.8 mm, 4.0 mm corner radius, 1.2 mm wall
  thickness, hollow internal cavity.
- Front HDMI cutout: 15 × 3.5 mm.
- Rear spring-loaded drop-jaw RJ45 expansion slot: 16 mm wide × 4.5 mm high
  at the rear wall (expands for Cat6 insertion while keeping the 6.8 mm
  profile).
- Side USB-C power/LAN pass-through port: 9 × 3.2 mm.

## Gaps / notes

- The document repeats the shell script several times; the first complete
  instance (which appears at the head of the document, before the thermal
  comparison sections) was installed.
- The script is a bare top-level `difference()` with the `rounded_cube`
  helper — no named top-level module — installed exactly as found.
- The "spring-loaded" behavior is described in the document's prose; the
  script models the fixed expansion slot geometry only.
