// Apple TV Air with LAN Architecture - Outer Enclosure Shell Concept
$fn = 60;

length = 84.0;      // Extended slightly for LAN PHY chip
width = 28.0;
thickness = 6.8;
corner_r = 4.0;
wall_thick = 1.2;

module rounded_cube(l, w, h, r) {
    hull() {
        translate([r, r, 0]) cylinder(r=r, h=h);
        translate([l-r, r, 0]) cylinder(r=r, h=h);
        translate([l-r, w-r, 0]) cylinder(r=r, h=h);
        translate([r, w-r, 0]) cylinder(r=r, h=h);
    }
}

difference() {
    // Outer Shell
    rounded_cube(length, width, thickness, corner_r);
    
    // Internal Cavity
    translate([wall_thick, wall_thick, wall_thick])
        rounded_cube(length - (wall_thick * 2), width - (wall_thick * 2), thickness - (wall_thick * 2), corner_r - 0.5);
        
    // HDMI Connector Cutout (Front)
    translate([-1, (width - 15) / 2, (thickness - 3.5) / 2])
        cube([wall_thick + 2, 15, 3.5]);
        
    // Drop-Jaw RJ45 Expansion Slot (Rear)
    translate([length - wall_thick - 1, (width - 16) / 2, 0])
        cube([wall_thick + 2, 16, 4.5]);

    // USB-C Power/LAN Pass-through Port (Side)
    translate([length - 18, -1, (thickness - 3.2) / 2])
        cube([9, wall_thick + 2, 3.2]);
}
