# OpenSCAD Project Set — Taylor Sprecher

Installed 2026-11-28 from Taylor's Google Drive source documents. All code was
extracted verbatim from the documents (chat-transcript-style .docx files);
nothing was retyped or re-dimensioned. Original .docx files are filed
unchanged in `~/workspace/user/files/`.

## Shared library

- [`lib/petg_tolerances.scad`](lib/petg_tolerances.scad) — PETG tolerance &
  clearance helpers shared across the set: the `petg_hole` module and the
  standard parameters from the Toyota single-port housing
  (`petg_hole_comp = 0.35`, `fit_snug = 0.25`, `keystone_clearance = 0.20`).
  Offsets summary: holes +0.35 mm, slot −0.25 mm, keystone +0.20 mm/side.

## Projects

- [`toyota-corolla-e210-dash-rj45/`](toyota-corolla-e210-dash-rj45/) —
  Toyota Corolla Hatchback (E210) Dash RJ45 LAN Housings.
  Tag: TOYOTA
  Single-port, dual-port, and console flange-mount keystone housings, plus
  single- and dual-port round threaded bulkhead variants with D-flat
  anti-rotation (dual adds a parametric center reinforcement rib).
  Source: AppleWatch LAN.docx. See the project README and PRINT_PROFILE.md.
- [`boeing-panel-mount-lan/`](boeing-panel-mount-lan/) — Aerospace
  Panel-Mount LAN Connector Housing. MIL-DTL-38999-inspired circular flange
  (38 mm dia, 31 mm 4-hole bolt circle), 28 mm barrel, 16.5 × 16.5 mm
  pass-through cavity; "Fully Featured" variant installed (5 variants exist
  in the source). Source: BOEING 3D LAN.docx.
- [`iphone-air-chassis/`](iphone-air-chassis/) — iPhone Air & Prototype
  Chassis Modules. 5.1 mm thin chassis (156.2 × 74.7 mm, Minkowski bevels)
  and a 50 × 50 × 18 mm LAN test dock (5.8 mm device slot, RJ45 cutout,
  USB-C trench). Sources: iPhone Air.docx, iPhone LAN connection set-up.docx.
- [`appletv-air-lan-shell/`](appletv-air-lan-shell/) — Apple TV Air Drop-Jaw
  LAN Shell. 84 × 28 × 6.8 mm rounded enclosure with rear spring-loaded
  expansion slot for Cat6 insertion. Source: AppleTV Air LAN.docx.
