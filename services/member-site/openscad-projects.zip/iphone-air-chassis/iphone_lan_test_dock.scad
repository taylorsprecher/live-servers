// ====================================================================
// OpenSCAD Prototype Chassis Module: iPhone Air + RJ45 & USB-C Integration
// ====================================================================

$fn = 60; // Smooth curves rendering

// --- Primary Module Dimensions ---
module_width  = 50;  // Width in mm
module_depth  = 50;  // Depth in mm
module_height = 18;  // Height/Thickness in mm
wall_thick    = 2.5; // Base wall thickness

// --- Device Slot Dimensions (e.g. Ultra-thin iPhone Air) ---
phone_thick   = 5.8;  // 5.6mm device thickness + 0.2mm print tolerance
phone_depth   = 12;   // Slot depth holding the device bottom edge

// --- Port Cutout Dimensions ---
// Standard female RJ45 jack housing cutout
rj45_w = 16.0; 
rj45_h = 14.0;
rj45_d = 22.0;

// Standard USB-C connector/plug channel routing
usbc_w = 12.5; 
usbc_h = 6.5; 
usbc_d = 20.0;

// --- Main Assembly ---
difference() {
    // 1. Solid Outer Base Housing
    cube([module_width, module_depth, module_height]);

    // 2. iPhone Slot Cutout (Top Surface Front Edge)
    translate([wall_thick, wall_thick, module_height - phone_thick])
        cube([module_width - (wall_thick * 2), phone_depth, phone_thick + 1]);

    // 3. RJ45 Ethernet Connector Cutout (Left Rear)
    translate([8, module_depth - rj45_d + 1, (module_height / 2) - (rj45_h / 2)])
        cube([rj45_w, rj45_d, rj45_h]);

    // 4. USB-C Cable Pass-Through / Routing Channel (Right Rear)
    translate([module_width - usbc_w - 8, module_depth - usbc_d + 1, (module_height / 2) - (usbc_h / 2)])
        cube([usbc_w, usbc_d, usbc_h]);

    // 5. Internal Cable Routing Trench (Connecting Ports inside the module)
    translate([wall_thick, phone_depth + wall_thick, wall_thick])
        cube([module_width - (wall_thick * 2), module_depth - phone_depth - (wall_thick * 2), module_height - (wall_thick * 2)]);

    // 6. M3 Screw Mounting Holes (Corners)
    translate([4, 4, -1]) cylinder(r=1.6, h=module_height + 2);
    translate([module_width - 4, 4, -1]) cylinder(r=1.6, h=module_height + 2);
    translate([4, module_depth - 4, -1]) cylinder(r=1.6, h=module_height + 2);
    translate([module_width - 4, module_depth - 4, -1]) cylinder(r=1.6, h=module_height + 2);
}
