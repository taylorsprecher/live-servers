# iPhone Air Chassis & LAN Test Dock

Source documents: **iPhone Air.docx** (chassis) and
**iPhone LAN connection set-up.docx** (test dock), Google Drive.
Installed 2026-11-28. Code extracted verbatim from the source documents.

## Files

| File | Assembly |
|---|---|
| `iphone_air_chassis.scad` | Parametric iPhone Air concept chassis (modules `iphone_chassis`, `camera_bump`, `screen_recess`, `side_buttons`) |
| `iphone_lan_test_dock.scad` | Prototype test dock / mounting module with device slot, RJ45 cutout, and USB-C routing trench (top-level `difference()`) |

## Headline specs (as found in the sources)

- **Chassis:** 156.2 mm height × 74.7 mm width × 5.1 mm depth; 12.0 mm corner
  radius; 0.8 mm Minkowski edge bevel; camera bump 36 × 36 × 2.2 mm; screen
  recess 0.4 mm deep; side button set (action, volume, side/power).
- **Test dock:** 50 × 50 × 18 mm module; device slot sized for a 5.8 mm thick
  device (source comment: 5.6 mm device + 0.2 mm print tolerance), 12 mm slot
  depth; RJ45 cutout 16.0 × 14.0 mm with 22.0 mm depth; USB-C channel
  12.5 × 6.5 mm with 20.0 mm depth; internal cable routing trench; four M3
  corner mounting holes (r = 1.6 mm).

## Gaps / notes

- Both documents repeat the same script several times (the chassis script
  appears 4× in iPhone Air.docx, the dock script 8× in iPhone LAN
  connection set-up.docx); the first complete instance of each was installed.
- Note the chassis script models a 5.1 mm device while the dock's slot is
  sized around a 5.6 mm device + 0.2 mm tolerance (5.8 mm slot) — the two
  source documents use different device-thickness figures (see the install
  report's mismatch list).
- The dock script is a bare top-level `difference()` with no named module —
  installed exactly as found.

## Fix — 2026-11-28 (Taylor's direction)
Cross-document mismatch corrected in the installed chassis file: `depth` was 5.1 mm while the test dock assumes a 5.6 mm device (slot 5.8 = 5.6 + 0.2 tolerance) and the chassis footprint (156.2 × 74.7 mm) matches the 5.6 mm device. `iphone_air_chassis.scad` now sets `depth = 5.6` with a fix note in its header; re-rendered successfully to STL (296 facets). The source document (iPhone Air.docx) is unchanged — the fix lives only in the installed copy. New MD5: `f81d8ec300312a72c7494bfec52d3306`.
