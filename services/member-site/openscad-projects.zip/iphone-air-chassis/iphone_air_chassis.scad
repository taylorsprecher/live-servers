// ====================================================================
// PARAMETRIC IPHONE AIR CONCEPT MODEL
// ====================================================================
// Units: Millimeters (mm)
// Fix 2026-11-28 (Taylor's direction): device depth corrected 5.1 -> 5.6 mm
// to match the test dock's device assumption (5.6 + 0.2 tolerance = 5.8 slot)
// and the chassis footprint dims (156.2 x 74.7). Source document unchanged.

$fn = 64; // High-resolution mesh curve rendering

// --- Dimensions ---
width           = 74.7;
height          = 156.2;
depth           = 5.6;
corner_radius   = 12.0;

// Edge Chamfer/Bevel
bevel_size      = 0.8;

// Camera Bump Parameters
cam_width       = 36.0;
cam_height      = 36.0;
cam_depth       = 2.2;
cam_radius      = 8.0;
cam_margin_top  = 4.0;
cam_margin_left = 4.0;

// Display Inset Parameters
screen_inset    = 0.5;
screen_depth    = 0.4;

// Side Controls Parameters
button_width    = 1.5;
button_depth    = 0.4;
vol_height      = 10.0;
action_height   = 6.0;
side_height     = 18.0;

// ====================================================================
// MODULES
// ====================================================================

// 2D Rounded Rectangle Base Profile
module rounded_rect_2d(w, h, r) {
    hull() {
        translate([r, r])             circle(r = r);
        translate([w - r, r])         circle(r = r);
        translate([w - r, h - r])     circle(r = r);
        translate([r, h - r])         circle(r = r);
    }
}

// Main Beveled Chassis Base
module iphone_chassis() {
    minkowski() {
        // Core block slightly reduced to allow for the 3D Minkowski bevel
        translate([bevel_size, bevel_size, bevel_size])
            linear_extrude(height = depth - (2 * bevel_size))
                rounded_rect_2d(width - (2 * bevel_size), height - (2 * bevel_size), max(0.1, corner_radius - bevel_size));
        
        // Chamfered bounding shape
        cylinder(r1 = bevel_size, r2 = 0, h = bevel_size, $fn = 4);
    }
}

// Camera Bump Platform
module camera_bump() {
    x_pos = cam_margin_left;
    y_pos = height - cam_margin_top - cam_height;
    
    translate([x_pos, y_pos, depth])
        linear_extrude(height = cam_depth)
            rounded_rect_2d(cam_width, cam_height, cam_radius);
}

// Screen Recess Cutout (Front Face)
module screen_recess() {
    translate([screen_inset, screen_inset, depth - screen_depth + 0.01])
        linear_extrude(height = screen_depth + 0.1)
            rounded_rect_2d(width - (2 * screen_inset), height - (2 * screen_inset), max(0.1, corner_radius - screen_inset));
}

// Side Buttons Assembly
module side_buttons() {
    // Left Rail: Action Button & Volume Buttons
    left_x = -button_depth;
    
    // Action Button
    translate([left_x, height - 25.0, (depth / 2) - (button_width / 2)])
        cube([button_depth + 0.1, action_height, button_width]);
        
    // Volume Up
    translate([left_x, height - 40.0, (depth / 2) - (button_width / 2)])
        cube([button_depth + 0.1, vol_height, button_width]);
        
    // Volume Down
    translate([left_x, height - 54.0, (depth / 2) - (button_width / 2)])
        cube([button_depth + 0.1, vol_height, button_width]);

    // Right Rail: Side / Power Button
    right_x = width - 0.1;
    translate([right_x, height - 45.0, (depth / 2) - (button_width / 2)])
        cube([button_depth + 0.1, side_height, button_width]);
}

// ====================================================================
// FINAL ASSEMBLY
// ====================================================================

difference() {
    union() {
        iphone_chassis();
        camera_bump();
        side_buttons();
    }
    
    // Subtractions
    screen_recess();
}
