// ====================================================================
// Universal Surface / Flange Mount Dual RJ45 Housing
// Ideal for Glove Box, Under-Seat, or Armrest Console Mounting
// ====================================================================

$fn = 60;

// Housing Dimensions
box_w = 48.0;
box_h = 28.0;
box_d = 32.0;
wall = 2.5;

// Flange Dimensions
flange_margin = 12.0;
screw_hole_d = 4.0;  // Fits standard M3.5 / M4 pan-head screws or zip-ties

module surface_flange_dual_rj45() {
    difference() {
        union() {
            // Main Housing Body
            translate([0, 0, box_d/2])
                cube([box_w, box_h, box_d], center=true);
            
            // Mounting Flange Plate
            cube([box_w + (flange_margin * 2), box_h, wall], center=true);
        }
        
        // Internal Hollow Box
        translate([0, 0, box_d/2 + wall])
            cube([box_w - (wall*2), box_h - (wall*2), box_d], center=true);
            
        // Keystone Port 1 Cutout
        translate([-11, 0, box_d/2])
            cube([14.8, 16.2, box_d + 10], center=true);

        // Keystone Port 2 Cutout
        translate([11, 0, box_d/2])
            cube([14.8, 16.2, box_d + 10], center=true);

        // Mounting Screw Holes (Left and Right Flange Sides)
        translate([-(box_w/2 + flange_margin/2), 0, 0])
            cylinder(d=screw_hole_d, h=wall + 2, center=true);
        translate([(box_w/2 + flange_margin/2), 0, 0])
            cylinder(d=screw_hole_d, h=wall + 2, center=true);
            
        // Cable Zip-Tie Pass-Throughs (Rear strain relief)
        translate([-11, (box_h/2) - 1.5, box_d - 4])
            cube([6, 2, 3], center=true);
        translate([11, (box_h/2) - 1.5, box_d - 4])
            cube([6, 2, 3], center=true);
    }
}

// Render Model
surface_flange_dual_rj45();
