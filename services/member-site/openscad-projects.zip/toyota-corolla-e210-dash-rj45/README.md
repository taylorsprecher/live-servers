# Toyota Corolla Hatchback (E210) Dash RJ45 LAN Housings

Tag: TOYOTA

Source document: **AppleWatch LAN.docx** (Google Drive; code-bearing copy —
a second Drive copy, AppleWatch LAN_b, contains no OpenSCAD code).
Installed 2026-11-28. Code extracted verbatim from the source document.

## Files

| File | Assembly |
|---|---|
| `single_port_dash_housing.scad` | Single-port keystone housing, module `toyota_lan_mount_petg` |
| `dual_port_dash_housing.scad` | Dual-port keystone housing, module `dual_port_toyota_mount` |
| `console_flange_mount.scad` | Glove box / console flange-mount dual housing, module `surface_flange_dual_rj45` |
| `single_port_round_bulkhead_housing.scad` | Single-port round threaded bulkhead variant with D-flat anti-rotation (added by Taylor, 2026-11-28) |
| `dual_port_round_bulkhead_housing.scad` | Dual-port round bulkhead variant with D-flats and parametric center reinforcement rib (added by Taylor, 2026-11-28) |
| `PRINT_PROFILE.md` | PETG slicer & tolerance profile from the source document |

## Headline specs (as found in the source)

- **Single-port (keystone):** 22.5 × 22.5 mm front bezel; 18.2 × 18.2 mm dash
  slot; body 17.95 × 17.95 mm (slot − 0.25 mm `fit_snug`); 28.0 mm body depth;
  internal keystone cutout from 14.8 × 16.2 mm nominal + 0.20 mm/side
  `keystone_clearance` (= 15.2 × 16.6 mm cavity); side retention snap clips;
  optional M2.5 set-screw hole via `petg_hole`.
- **Dual-port (keystone):** 32.5 × 22.0 mm bezel for the large Toyota switch
  blank; 28.0 × 17.5 mm body; two 14.5 × 16.0 mm keystone cutouts at 15.0 mm
  port spacing.
- **Console flange mount:** 48 × 28 × 32 mm housing, 2.5 mm walls, mounting
  flange with M3.5/M4 screw holes (4.0 mm), two 14.8 × 16.2 mm keystone
  cutouts, rear zip-tie strain-relief slots.
- **Single-port round bulkhead:** same 22.5 × 22.5 mm bezel / 18.2 × 18.2 mm
  slot fitment; 20.2 mm round bore for a threaded panel-mount RJ45 bulkhead;
  3.0 mm bezel; 24.0 mm body depth; rear nut relief pocket (24.0 mm dia ×
  4.0 mm); optional M2.5 set-screw hole.
- **Dual-port round bulkhead:** 32.5 × 22.0 mm bezel; two 15.0 mm bulkhead
  bores at 16.0 mm spacing; rear relief pockets (17.5 mm dia × 3.5 mm);
  parametric center reinforcement rib between the ports.

## Round bulkhead variants — anti-rotation: D-flat

Anti-rotation is a **D-flat** cut into the bore (not a key notch):
`use_d_flat` toggles it, `d_flat_cut` sets the chord depth, and
`d_flat_angle` orients it (0 = +X/right, 90 = +Y/top, 180 = −X, 270 = −Y).

**Measurement tip (Taylor):** measure the connector barrel's widest round
diameter **D** and the flat-to-round thickness **W_flat** with calipers, then
set `d_flat_cut = D − W_flat`. Example (Taylor's): an M20 bulkhead with
D = 20.0 mm measuring 18.6 mm across the flat takes `d_flat_cut = 1.4 mm`.

## Fitment notes — single-port round bulkhead (Taylor)

1. With an 18.2 mm slot and a 20.2 mm bore, the bore is slightly wider than
   the slot — the connector flange/nut bears on the 22.5 mm bezel or rear
   face while the 17.95 mm body locates the insert. For full circular wall
   support with barrels over 17.5 mm, widen `body_w`/`body_h` or trim the
   dash slot.
2. Check connector barrel + rear boot length against `body_depth` = 24.0 mm.

## Fitment notes — dual-port round bulkhead (Taylor)

- `port_spacing` must be at least `bulkhead_hole_d + nut_across_flats +
  1.0 mm` so the two locking nuts don't collide.
- With `body_h` 17.5 mm and 15.0 mm bores (+0.35 PETG = 15.35 mm) at 16.0 mm
  spacing, side walls run ~1.0 mm — adjust `bulkhead_hole_d` /
  `port_spacing` / body dims to the actual connector.
- Print bezel face-down, 0.16 mm layers, 4+ walls.

## Center rib tuning — dual-port round bulkhead (Taylor)

- `rib_thickness` 1.6–2.4 mm in PETG gives a solid bridge when spacing is
  tight.
- Lower `rib_depth_ratio` (e.g. 0.65) or shift `rib_z_offset` to concentrate
  the rib toward the bezel or away from rear boots.

## Gaps

- None in the code: all three document assemblies and both of Taylor's
  bulkhead variants are complete, self-contained scripts with parameter
  blocks and trailing render calls.
- The source document is a long chat transcript containing much unrelated
  material (other vehicles, a semi-truck model, etc.); only the three Toyota
  assemblies above were extracted, per the project scope.
