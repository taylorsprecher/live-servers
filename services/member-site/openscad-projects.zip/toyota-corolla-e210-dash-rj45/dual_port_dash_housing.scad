// ====================================================================
// Toyota Corolla Hatchback - Dual RJ45 Dash Switch Housing
// Fits Large Toyota Switch Slot (~32.5mm x 22.0mm face)
// ====================================================================

$fn = 60;

// Dash Slot Dimensions (Toyota Large Format)
face_w = 32.5;       // Outer bezel width (mm)
face_h = 22.0;       // Outer bezel height (mm)
bezel_thick = 2.5;   // Front lip thickness (mm)
body_w = 28.0;       // Insertion body width (mm)
body_h = 17.5;       // Insertion body height (mm)
body_depth = 28.0;   // Insertion depth (mm)

// Standard Keystone Dimensions
keystone_w = 14.5;   // Width per keystone cutout (mm)
keystone_h = 16.0;   // Height per keystone cutout (mm)
port_spacing = 15.0; // Distance between port centers (mm)

module dual_port_toyota_mount() {
    difference() {
        union() {
            // 1. Outer Bezel
            hull() {
                cube([face_w - 2, face_h - 2, bezel_thick], center=true);
                translate([0,0,-0.5])
                    cube([face_w, face_h, bezel_thick - 1], center=true);
            }
            
            // 2. Main Body Chassis
            translate([0, 0, -(body_depth / 2 + bezel_thick / 2)])
                cube([body_w, body_h, body_depth], center=true);
            
            // 3. Dash Retention Clips (Left and Right)
            translate([body_w/2 + 0.6, 0, -12])
                rotate([0, 90, 0])
                    cylinder(r1=1.5, r2=0, h=1.2, center=true);
            translate([-(body_w/2 + 0.6), 0, -12])
                rotate([0, -90, 0])
                    cylinder(r1=1.5, r2=0, h=1.2, center=true);
        }
        
        // 4. Port Cutouts (Side-by-Side)
        for (offset = [-port_spacing/2, port_spacing/2]) {
            // Main Through-Hole
            translate([offset, 0, -15])
                cube([keystone_w, keystone_h, body_depth + 10], center=true);
                
            // Top & Bottom Snap Retainers
            translate([offset, (keystone_h/2) + 0.5, -body_depth + 4])
                cube([keystone_w, 2.0, 1.8], center=true);
            translate([offset, -(keystone_h/2) - 0.5, -body_depth + 4])
                cube([keystone_w, 2.0, 1.8], center=true);
        }
    }
}

// Render Model
dual_port_toyota_mount();
