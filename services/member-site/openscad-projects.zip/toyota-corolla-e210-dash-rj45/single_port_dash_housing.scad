// ====================================================================
// Toyota Corolla Hatchback - Custom Dash RJ45 LAN Housing (PETG Optimized)
// Fits Small Toyota Switch Slot (~22.5mm x 22.5mm face)
// ====================================================================

$fn = 60;

// --------------------------------------------------------------------
// 1. PETG Tolerance & Fit Parameters
// --------------------------------------------------------------------
petg_hole_comp     = 0.35; // Expansion offset for circular holes
fit_snug           = 0.25; // Friction clearance for dash slot insertion
keystone_clearance = 0.20; // Per-side offset for internal keystone pocket

// --------------------------------------------------------------------
// 2. Toyota Dash Slot Nominal Dimensions
// --------------------------------------------------------------------
dash_slot_w        = 18.2; // Vehicle slot width (mm)
dash_slot_h        = 18.2; // Vehicle slot height (mm)
face_w             = 22.5; // Outer bezel width (mm)
face_h             = 22.5; // Outer bezel height (mm)
bezel_thick        = 2.5;  // Outer bezel lip thickness (mm)
body_depth         = 28.0; // Overall insertion depth (mm)

// Applied PETG Body Dimensions
body_w = dash_slot_w - fit_snug; // 17.95mm (prevents binding)
body_h = dash_slot_h - fit_snug; // 17.95mm

// --------------------------------------------------------------------
// 3. Keystone Jack Nominal & PETG-Adjusted Dimensions
// --------------------------------------------------------------------
keystone_w_nom = 14.8;
keystone_h_nom = 16.2;
latch_lip_h    = 1.8;

// Applied PETG Keystone Cavity Dimensions
keystone_w = keystone_w_nom + (keystone_clearance * 2); // 15.2mm
keystone_h = keystone_h_nom + (keystone_clearance * 2); // 16.6mm

// --------------------------------------------------------------------
// 4. Helper Modules
// --------------------------------------------------------------------
module petg_hole(d, h, center=true) {
    // Corrects for PETG hole shrinkage and polygon discretization
    d_actual = d + petg_hole_comp;
    cylinder(d=d_actual, h=h, center=center, $fn=max(30, d*4));
}

// --------------------------------------------------------------------
// 5. Main Assembly
// --------------------------------------------------------------------
module toyota_lan_mount_petg() {
    difference() {
        union() {
            // A. Front Bezel (Sits flush on dash trim)
            hull() {
                cube([face_w - 2, face_h - 2, bezel_thick], center=true);
                translate([0, 0, -0.5])
                    cube([face_w, face_h, bezel_thick - 1], center=true);
            }
            
            // B. Inserting Body Chassis (Subtracted by fit_snug offset)
            translate([0, 0, -(body_depth / 2 + bezel_thick / 2)])
                cube([body_w, body_h, body_depth], center=true);
            
            // C. Side Retention Snap Clips (PETG Flex-Lock Tabs)
            // Left clip
            translate([body_w/2 + 0.6, 0, -12])
                rotate([0, 90, 0])
                    cylinder(r1=1.5, r2=0, h=1.2, center=true);
            // Right clip
            translate([-(body_w/2 + 0.6), 0, -12])
                rotate([0, -90, 0])
                    cylinder(r1=1.5, r2=0, h=1.2, center=true);
        }
        
        // D. Main Pass-Through Channel (Clears Keystone + Cables)
        translate([0, 0, -15])
            cube([keystone_w, keystone_h, body_depth + 10], center=true);
            
        // E. Keystone Latch Snap Recesses (Top & Bottom internal lips)
        translate([0, (keystone_h/2) + 0.5, -body_depth + 4])
            cube([keystone_w, 2.0, latch_lip_h + 0.2], center=true);
            
        translate([0, -(keystone_h/2) - 0.5, -body_depth + 4])
            cube([keystone_w, 2.0, latch_lip_h + 0.2], center=true);

        // F. Optional Bottom M2.5 Set-Screw Locking Hole (Uses petg_hole)
        // Set-screw can lock the keystone permanently if desired
        translate([0, -(body_h/2 + 1), -18])
            rotate([90, 0, 0])
                petg_hole(d=2.5, h=10, center=true);
    }
}

// Render Model
toyota_lan_mount_petg();
