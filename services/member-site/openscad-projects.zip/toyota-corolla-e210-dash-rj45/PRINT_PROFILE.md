# PETG Slicer & Tolerance Profile — Toyota Corolla E210 Dash Housings

From the source document (AppleWatch LAN.docx), the comprehensive PETG
automotive slicer profile:

| Setting / Parameter | Recommended Value | Notes |
|---|---|---|
| Material | PETG (or ASA/ABS for upper dash) | PLA warps in cabin heat; PETG suits interior cabin heat resistance |
| Orientation | Face-down on build plate | Bezel face down; flange mount prints flange flat |
| Layer Height | 0.16–0.20 mm | 0.16 mm recommended for snap clips |
| Walls | 4–5 perimeters (~1.6–2.0 mm with 0.4 mm nozzle) | Clips/snap-fits print as solid perimeters |
| Top / Bottom Shell | 5–6 / 4–5 layers | |
| Infill | 35%–50% Gyroid or 3D Honeycomb | Isotropic load distribution under vibration |
| Hotend Temp | 240–250 °C (first layer 245–250 °C) | |
| Bed Temp | 75–85 °C (first layer 85 °C) | |
| Line Width | 0.44–0.48 mm on a 0.4 mm nozzle | Improves interlayer adhesion |
| PETG Offsets | Holes +0.35 mm, Slot −0.25 mm, Keystone +0.20 mm/side | See `../lib/petg_tolerances.scad` |

Print speeds (from the document's PETG automotive speed profile): first layer
20–30 mm/s, outer wall 40–60 mm/s, inner walls 60–80 mm/s, infill 80–100 mm/s,
top/bottom surface 45–55 mm/s, travel 150–250 mm/s.
