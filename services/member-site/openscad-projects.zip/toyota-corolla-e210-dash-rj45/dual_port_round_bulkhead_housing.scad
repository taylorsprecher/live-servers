// ====================================================================
// Toyota Corolla Hatchback - Dual-Port Round Bulkhead RJ45 Housing
// Fits Large Toyota Switch Slot (~32.5mm x 22.0mm face)
// Configured for Two Round Threaded Panel-Mount RJ45 Connectors with D-Flats
// Includes Parametric Center Reinforcement Rib Between Ports
// ====================================================================

$fn = 72;

// 1. PETG Tolerance & Fit Parameters
petg_hole_comp = 0.35; // Diameter compensation for circular holes/bores (mm)
fit_snug       = 0.25; // Clearance offset for dash slot insertion (mm)

// 2. Toyota Large Switch Slot Dimensions
face_w      = 32.5; // Outer bezel width (mm)
face_h      = 22.0; // Outer bezel height (mm)
bezel_thick = 3.0;  // Front lip thickness (mm) - sized for threaded bulkhead seating

dash_slot_w = 28.0; // Nominal vehicle switch slot width (mm)
dash_slot_h = 17.5; // Nominal vehicle switch slot height (mm)
body_depth  = 24.0; // Insertion depth behind bezel (mm)

// Applied PETG Body Dimensions
body_w = dash_slot_w - fit_snug; // 27.75 mm
body_h = dash_slot_h - fit_snug; // 17.25 mm

// 3. Dual Round Threaded RJ45 Bulkhead + D-Flat Parameters
bulkhead_hole_d = 15.0; // Nominal bore diameter per connector (mm) - adjust to barrel OD
port_spacing    = 16.0; // Center-to-center spacing between left and right ports (mm)

use_d_flat      = true; // Set false for plain round bores
d_flat_cut      = 1.2;  // Chord depth measured inward from bore circle edge (mm)
d_flat_angle    = 0;    // Orientation in degrees: 0 = +X, 90 = +Y, 180 = -X, 270 = -Y

// 4. Parametric Center Reinforcement Rib Parameters
use_center_rib  = true; // Toggle center rib between the two ports
rib_thickness   = 2.0;  // Rib width along X axis (mm)
rib_depth_ratio = 0.85; // Fraction of (bezel_thick + body_depth) spanned by the rib (0.0 - 1.0)
rib_z_offset    = 0.0;  // Vertical shift along Z axis (mm)

// Optional rear jam-nut / cable-boot relief on back of housing
use_rear_nut_relief = true;
rear_nut_d          = 17.5; // Diameter to clear rear locking nut / boot (mm)
rear_nut_depth      = 3.5;  // Depth of rear relief pocket (mm)

// 5. Helper Modules
module petg_hole(d, h, center=true) {
    // Compensates for PETG shrinkage and polygon discretization
    d_actual = d + petg_hole_comp;
    cylinder(d=d_actual, h=h, center=center, $fn=max(48, round(d_actual * 5)));
}

module single_d_flat_bore(h) {
    d_actual = bulkhead_hole_d + petg_hole_comp;

    rotate([0, 0, d_flat_angle]) {
        if (use_d_flat && d_flat_cut > 0) {
            intersection() {
                petg_hole(d=bulkhead_hole_d, h=h, center=true);

                // Trims the +X side of the cylinder by d_flat_cut to form the D-flat
                translate([-d_flat_cut / 2, 0, 0])
                    cube([d_actual - d_flat_cut, d_actual + 2, h + 2], center=true);
            }
        } else {
            petg_hole(d=bulkhead_hole_d, h=h, center=true);
        }
    }
}

module center_reinforcement_rib(total_depth) {
    rib_h = rib_depth_ratio * total_depth;
    translate([0, 0, -(total_depth / 2) + rib_z_offset])
        cube([rib_thickness, body_h, rib_h], center=true);
}

// 6. Main Assembly
module dual_port_toyota_bulkhead_mount() {
    total_depth = bezel_thick + body_depth;

    difference() {
        union() {
            // A. Outer Front Bezel
            hull() {
                translate([0, 0, -bezel_thick/2])
                    cube([face_w - 2, face_h - 2, bezel_thick], center=true);
                translate([0, 0, -bezel_thick/2 - 0.5])
                    cube([face_w, face_h, max(1.0, bezel_thick - 1)], center=true);
            }

            // B. Main Body Chassis
            translate([0, 0, -(bezel_thick + body_depth/2)])
                cube([body_w, body_h, body_depth], center=true);

            // C. Dash Retention Snap Clips (Left and Right)
            translate([body_w/2 + 0.6, 0, -(bezel_thick + 11)])
                rotate([0, 90, 0])
                    cylinder(r1=1.5, r2=0, h=1.2, center=true);

            translate([-(body_w/2 + 0.6), 0, -(bezel_thick + 11)])
                rotate([0, -90, 0])
                    cylinder(r1=1.5, r2=0, h=1.2, center=true);

            // D. Parametric Center Reinforcement Rib Between Ports
            if (use_center_rib && rib_thickness > 0 && rib_depth_ratio > 0) {
                center_reinforcement_rib(total_depth);
            }
        }

        // E. Dual Through-Bores with D-Flats (Side-by-Side)
        for (offset = [-port_spacing/2, port_spacing/2]) {
            translate([offset, 0, -total_depth/2])
                single_d_flat_bore(h=total_depth + 4);

            // F. Rear Relief Pocket per Port
            if (use_rear_nut_relief) {
                translate([offset, 0, -(total_depth - rear_nut_depth/2)])
                    petg_hole(d=rear_nut_d, h=rear_nut_depth + 0.4, center=true);
            }
        }
    }
}

dual_port_toyota_bulkhead_mount();
