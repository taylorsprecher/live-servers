// ====================================================================
// Toyota Corolla Hatchback - Single-Port Round Bulkhead RJ45 Housing
// Fits Small Toyota Switch Slot (~22.5mm x 22.5mm face)
// Configured for Round Threaded Panel-Mount RJ45 with D-Flat Anti-Rotation
// ====================================================================

$fn = 72;

// 1. PETG Tolerance & Fit Parameters
petg_hole_comp = 0.35; // Diameter compensation for circular holes/bores (mm)
fit_snug       = 0.25; // Clearance offset for dash slot insertion (mm)

// 2. Toyota Dash Slot Nominal Dimensions
dash_slot_w = 18.2; // Vehicle slot width (mm)
dash_slot_h = 18.2; // Vehicle slot height (mm)
face_w      = 22.5; // Outer bezel width (mm)
face_h      = 22.5; // Outer bezel height (mm)
bezel_thick = 3.0;  // Front face thickness (mm)
body_depth  = 24.0; // Overall insertion depth (mm)

// Applied PETG Body Dimensions
body_w = dash_slot_w - fit_snug; // 17.95 mm
body_h = dash_slot_h - fit_snug; // 17.95 mm

// 3. Round Threaded Panel-Mount RJ45 Bulkhead + D-Flat Parameters
bulkhead_hole_d = 20.2; // Nominal mounting bore diameter (mm)
use_d_flat      = true; // Set false for a plain round hole
d_flat_cut      = 1.4;  // Depth of flat chord measured inward from outer circle edge (mm)
d_flat_angle    = 0;    // Orientation in degrees: 0 = right (+X), 90 = top (+Y), 180 = left, 270 = bottom

// Optional rear jam-nut / cable-boot relief pocket on back of housing
use_rear_nut_relief = true;
rear_nut_d          = 24.0; // Diameter to clear panel nut / connector collar (mm)
rear_nut_depth      = 4.0;  // Depth of rear relief pocket (mm)

// 4. Helper Modules
module petg_hole(d, h, center=true) {
    // Compensates for PETG shrinkage and polygon discretization
    d_actual = d + petg_hole_comp;
    cylinder(d=d_actual, h=h, center=center, $fn=max(48, round(d_actual * 5)));
}

module bulkhead_bore_profile(h) {
    d_actual = bulkhead_hole_d + petg_hole_comp;
    r_actual = d_actual / 2;

    rotate([0, 0, d_flat_angle]) {
        if (use_d_flat && d_flat_cut > 0) {
            intersection() {
                petg_hole(d=bulkhead_hole_d, h=h, center=true);

                // Trims the +X side of the cylinder by d_flat_cut to form the D-flat
                translate([-d_flat_cut / 2, 0, 0])
                    cube([d_actual - d_flat_cut, d_actual + 2, h + 2], center=true);
            }
        } else {
            petg_hole(d=bulkhead_hole_d, h=h, center=true);
        }
    }
}

// 5. Main Assembly
module toyota_bulkhead_rj45_mount() {
    total_depth = bezel_thick + body_depth;

    difference() {
        union() {
            // A. Front Bezel (Sits flush on dash trim)
            hull() {
                translate([0, 0, -bezel_thick/2])
                    cube([face_w - 2, face_h - 2, bezel_thick], center=true);
                translate([0, 0, -bezel_thick/2 - 0.5])
                    cube([face_w, face_h, max(1.0, bezel_thick - 1)], center=true);
            }

            // B. Inserting Body Chassis (Sized for dash slot with PETG clearance)
            translate([0, 0, -(bezel_thick + body_depth/2)])
                cube([body_w, body_h, body_depth], center=true);

            // C. Side Retention Snap Clips (PETG Flex-Lock Tabs)
            translate([body_w/2 + 0.6, 0, -(bezel_thick + 11)])
                rotate([0, 90, 0])
                    cylinder(r1=1.5, r2=0, h=1.2, center=true);

            translate([-(body_w/2 + 0.6), 0, -(bezel_thick + 11)])
                rotate([0, -90, 0])
                    cylinder(r1=1.5, r2=0, h=1.2, center=true);
        }

        // D. Through-Bore with D-Flat for Threaded RJ45 Bulkhead Connector
        translate([0, 0, -total_depth/2])
            bulkhead_bore_profile(h=total_depth + 4);

        // E. Rear Relief Pocket (Clears locking nut / rear cable strain boot)
        if (use_rear_nut_relief) {
            translate([0, 0, -(total_depth - rear_nut_depth/2)])
                petg_hole(d=rear_nut_d, h=rear_nut_depth + 0.4, center=true);
        }

        // F. Optional Bottom M2.5 Set-Screw Locking Hole
        translate([0, -(body_h/2 + 1), -(bezel_thick + 16)])
            rotate([90, 0, 0])
                petg_hole(d=2.5, h=10, center=true);
    }
}

toyota_bulkhead_rj45_mount();
