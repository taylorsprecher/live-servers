# Aerospace Panel-Mount LAN Connector Housing (Boeing style)

Source document: **BOEING 3D LAN.docx** (Google Drive). Installed 2026-11-28.
Code extracted verbatim from the source document.

## Files

| File | Assembly |
|---|---|
| `boeing_panel_mount_lan.scad` | Panel-mount connector housing, module `connector_housing` — the "Fully Featured" variant (see Variants) |

## Headline specs (as found in the source)

- MIL-DTL-38999-inspired circular mounting flange: 38.0 mm outer diameter,
  3.5 mm thick.
- 4 mounting holes on a 31.0 mm bolt circle, 3.2 mm clearance holes with
  6.0 mm × 1.5 mm counterbores for socket head cap screws.
- Main barrel/shell: 28.0 mm diameter, 22.0 mm height, with a stress-relief
  fillet at the flange/shell junction.
- Internal pass-through cavity: 16.5 × 16.5 mm, 25.0 mm deep, for shielded
  CAT6A or Quadrax inserts; alignment keyway/polarization notch (2.5 × 1.2 mm).
- O-ring sealing groove on the mating face (33.0 mm pitch dia, 1.5 mm wide,
  1.0 mm deep).
- Radial M3 set-screw retention hole (2.5 mm tap drill) at 12.0 mm shell height.
- `wall_min = 2.0` parameter for manufacturing-method adjustment (printing
  vs CNC); document suggests PEEK, ULTEM, carbon-fiber Nylon, or anodized
  aluminum.

## Variants in the source document

The document holds **five** successive versions of `connector_housing`:

1. Base version — flange, barrel, cavity, 4 holes, base pocketing.
2. "Corrected" version — syntax fix to the mounting-hole loop, semicolons.
3. Adds stress-relief fillet, alignment keyway, and O-ring groove.
4. Adds mounting-hole counterbores and the radial set-screw retention hole.
5. **"Fully Featured" (installed)** — all of the above combined.

Only variant 5 is installed; variants 1–4 remain in the source document.

## Gaps

- None in the installed code: variant 5 is a complete script with parameter
  block and trailing render call.
