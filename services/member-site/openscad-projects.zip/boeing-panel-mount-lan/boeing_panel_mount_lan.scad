// ==========================================
// Aerospace LAN Connector Housing (Boeing Spec Style - Fully Featured)
// Unit: millimeters
// ==========================================
$fn = 100; // Smooth rendering for circular features

// Parameters & Variables
flange_dia = 38.0;          // Outer mounting flange diameter
flange_thick = 3.5;         // Thickness of the mounting flange
shell_dia = 28.0;           // Main barrel/shell diameter
shell_height = 22.0;        // Total height from back of flange
bolt_circle_dia = 31.0;     // Pitch circle diameter for mounting holes
bolt_hole_dia = 3.2;        // Clearance holes for mounting screws (#4-40 or M3)
num_holes = 4;              // Number of mounting lugs/holes

// Counterbore parameters for socket head cap screws
counterbore_dia = 6.0;      
counterbore_depth = 1.5;    

// Wall thickness parameter for manufacturing method adjustment
wall_min = 2.0;

// Internal cavity for Ethernet/LAN insert (e.g., RJ45 or Quadrax sleeve)
cavity_width = 16.5;    
cavity_length = 16.5;   
cavity_depth = 25.0;    

// O-ring groove parameters
oring_dia = 33.0;       
oring_width = 1.5;      
oring_depth = 1.0;      

// Keyway parameters
key_width = 2.5;
key_depth = 1.2;

// Insert retention / locking set-screw thread parameters (e.g., M3 radial threaded hole)
set_screw_dia = 2.5;        // Tap drill hole for M3 thread
set_screw_height = 12.0;    // Height position along the shell for the retention screw

module connector_housing() {
    difference() {
        // Main Body Assembly with Stress-Relief Fillet at Flange/Shell Junction
        union() {
            // Mounting Flange
            cylinder(h = flange_thick, d = flange_dia, center = false);
            
            // Stress-relief fillet / transition chamfer
            translate([0, 0, flange_thick])
                cylinder(h = 1.5, r1 = shell_dia/2 + 1.5, r2 = shell_dia/2);
            
            // Main Shell / Barrel
            translate([0, 0, flange_thick + 1.5])
                cylinder(h = shell_height - 1.5, d = shell_dia, center = false);
        }
        
        // Central Pass-Through Cavity for LAN Insert
        translate([0, 0, -1])
            cube([cavity_width, cavity_length, cavity_depth + flange_thick], center = true);
            
        // Alignment Keyway / Polarization Notch inside Cavity
        translate([0, cavity_length/2 - 1, 0])
            cube([key_width, key_depth * 2, cavity_depth + flange_thick], center = true);

        // O-Ring Sealing Groove on Mating Face (Top of Flange)
        translate([0, 0, flange_thick - oring_depth])
            rotate_extrude()
                translate([oring_dia / 2, 0, 0])
                    square([oring_width, oring_depth + 1]);

        // Flange Mounting Holes and Counterbores (Distributed Radially)
        for (i = [0 : num_holes - 1]) {
            rotate([0, 0, i * (360 / num_holes)]) {
                // Through hole for screw clearance
                translate([bolt_circle_dia / 2, 0, -1])
                    cylinder(h = flange_thick + 2, d = bolt_hole_dia);
                
                // Counterbore recess on top face for socket head cap screw heads
                translate([bolt_circle_dia / 2, 0, flange_thick - counterbore_depth])
                    cylinder(h = counterbore_depth + 1, d = counterbore_dia);
            }
        }
        
        // Radial Set-Screw Hole for Locking/Retaining the Insert inside the Barrel
        translate([0, 0, flange_thick + set_screw_height])
            rotate([0, 90, 0])
                cylinder(h = shell_dia, d = set_screw_dia, center = true);
        
        // Weight-reduction / strain-relief pocketing on the flange base
        translate([0, 0, flange_thick - 1.0])
            cylinder(h = 1.2, d = shell_dia + 3.0);
    }
}

// Render Model
connector_housing();
