// ====================================================================
// PETG Tolerance & Clearance Library (shared)
// Extracted verbatim from the Toyota Corolla E210 single-port dash
// housing (AppleWatch LAN.docx) so every project in this set uses the
// same PETG fitment helpers.
//
// Standard PETG offsets used across this project set:
//   Holes:    +0.35 mm diameter (petg_hole_comp)
//   Slot fit: -0.25 mm (fit_snug) friction clearance for dash slots
//   Keystone: +0.20 mm per side (keystone_clearance) pocket clearance
// ====================================================================

// PETG Tolerance & Fit Parameters
petg_hole_comp     = 0.35; // Expansion offset for circular holes
fit_snug           = 0.25; // Friction clearance for dash slot insertion
keystone_clearance = 0.20; // Per-side offset for internal keystone pocket

// Helper Modules
module petg_hole(d, h, center=true) {
    // Corrects for PETG hole shrinkage and polygon discretization
    d_actual = d + petg_hole_comp;
    cylinder(d=d_actual, h=h, center=center, $fn=max(30, d*4));
}
